import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const outDir = path.resolve('public/assets');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// 1. App Icon SVG
const appIconSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a0d11" />
      <stop offset="60%" stop-color="#141920" />
      <stop offset="100%" stop-color="#050608" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fff176" />
      <stop offset="50%" stop-color="#ffe000" />
      <stop offset="100%" stop-color="#e65100" />
    </linearGradient>
    <linearGradient id="redGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ff5252" />
      <stop offset="100%" stop-color="#d50000" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>
  <rect width="512" height="512" rx="104" fill="url(#bgGrad)" />
  <circle cx="256" cy="256" r="230" fill="none" stroke="#263039" stroke-width="6" stroke-dasharray="16 10" opacity="0.6" />
  
  <!-- Aura glow behind crown -->
  <circle cx="256" cy="210" r="140" fill="#ffe000" opacity="0.12" filter="url(#glow)" />
  <circle cx="256" cy="280" r="110" fill="#ff3b30" opacity="0.10" filter="url(#glow)" />

  <!-- Crown Icon -->
  <path d="M156 220 L196 140 L256 185 L316 140 L356 220 Z" fill="url(#goldGrad)" filter="url(#glow)"/>
  <circle cx="196" cy="132" r="10" fill="#fff" />
  <circle cx="256" cy="177" r="12" fill="#fff" />
  <circle cx="316" cy="132" r="10" fill="#fff" />
  
  <!-- Crown Base Bar -->
  <rect x="146" y="222" width="220" height="22" rx="6" fill="#ffe000" />

  <!-- Bold Japanese Katakana Accent: アニメ -->
  <text x="256" y="285" font-family="'Barlow Condensed', 'Arial Black', sans-serif" font-weight="900" font-size="28" fill="#ff5252" letter-spacing="8" text-anchor="middle">ANIME UNIVERSE</text>

  <!-- AWSK_EDITZ stylized text -->
  <text x="256" y="365" font-family="'Barlow Condensed', 'Arial Black', sans-serif" font-style="italic" font-weight="900" font-size="64" fill="url(#goldGrad)" text-anchor="middle" filter="url(#glow)">AWSK<tspan fill="#ffffff">_EDITZ</tspan></text>
  <text x="256" y="415" font-family="sans-serif" font-weight="800" font-size="16" fill="#8f979f" letter-spacing="4" text-anchor="middle">HINGLISH MANGA &amp; EDITS</text>
</svg>
`;

// 2. Hero Banner SVG
const heroBannerSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 480" width="1400" height="480">
  <defs>
    <linearGradient id="hBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#05070a" />
      <stop offset="40%" stop-color="#121820" />
      <stop offset="80%" stop-color="#1a0b0d" />
      <stop offset="100%" stop-color="#07090b" />
    </linearGradient>
    <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ffe000" />
      <stop offset="100%" stop-color="#ffb300" />
    </linearGradient>
    <linearGradient id="crimson" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ff3b30" />
      <stop offset="100%" stop-color="#b71c1c" />
    </linearGradient>
    <pattern id="mangaDots" width="16" height="16" patternUnits="userSpaceOnUse">
      <circle cx="4" cy="4" r="1.5" fill="#ffffff" opacity="0.07" />
      <circle cx="12" cy="12" r="1.5" fill="#ffffff" opacity="0.07" />
    </pattern>
    <filter id="hGlow">
      <feGaussianBlur stdDeviation="12" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>
  <rect width="1400" height="480" fill="url(#hBg)" />
  <rect width="1400" height="480" fill="url(#mangaDots)" />

  <!-- Diagonal speed / slash energy lines -->
  <polygon points="0,0 260,0 120,480 0,480" fill="#ffe000" opacity="0.12" />
  <polygon points="1100,0 1400,0 1400,480 980,480" fill="#ff3b30" opacity="0.14" />
  <line x1="150" y1="0" x2="350" y2="480" stroke="#ffe000" stroke-width="4" opacity="0.25" />
  <line x1="880" y1="0" x2="1080" y2="480" stroke="#ff3b30" stroke-width="4" opacity="0.25" />

  <!-- Background decorative Manga Japanese / Emblem -->
  <text x="100" y="160" font-family="'Arial Black', sans-serif" font-size="120" font-weight="900" fill="#ffffff" opacity="0.03">うずまき</text>
  <text x="960" y="390" font-family="'Arial Black', sans-serif" font-size="100" font-weight="900" fill="#ff3b30" opacity="0.05">紅蓮の炎</text>

  <!-- Glowing Aura Circle center-right -->
  <circle cx="950" cy="240" r="170" fill="none" stroke="#ffe000" stroke-width="8" opacity="0.2" stroke-dasharray="24 12" />
  <circle cx="950" cy="240" r="120" fill="#ffe000" opacity="0.07" filter="url(#hGlow)" />
  
  <!-- Left Side Hero Content -->
  <g transform="translate(110, 130)">
    <!-- Crown -->
    <path d="M0,20 L18,-15 L40,6 L62,-15 L80,20 Z" fill="url(#gold)" filter="url(#hGlow)" />
    <!-- Tagline pills -->
    <rect x="0" y="32" width="170" height="26" rx="4" fill="#0d1115" stroke="#ffe000" stroke-width="1.5" />
    <text x="12" y="49" font-family="sans-serif" font-weight="900" font-size="11" fill="#ffe000" letter-spacing="2">✦ ANIME EDITS</text>
    
    <rect x="180" y="32" width="180" height="26" rx="4" fill="#0d1115" stroke="#ff3b30" stroke-width="1.5" />
    <text x="192" y="49" font-family="sans-serif" font-weight="900" font-size="11" fill="#ff7069" letter-spacing="2">✦ ACTION SHORTS</text>

    <!-- Main Title -->
    <text x="0" y="125" font-family="'Barlow Condensed', 'Arial Black', sans-serif" font-style="italic" font-weight="900" font-size="94" fill="url(#gold)" filter="url(#hGlow)">AWSK<tspan fill="#ffffff">_EDITZ</tspan></text>
    <text x="0" y="165" font-family="sans-serif" font-weight="800" font-size="20" fill="#ff3b30" letter-spacing="4">BEYOND THE FRAMES. INTO THE STORY.</text>
    <text x="0" y="200" font-family="sans-serif" font-size="15" fill="#a0abb5">Official Hinglish Manga, Fan Animations, Edits &amp; Original Stories</text>
  </g>

  <!-- Bottom aesthetic border -->
  <rect x="0" y="474" width="1400" height="6" fill="url(#gold)" />
</svg>
`;

// 3. Manga Covers SVG
function createMangaCoverSvg(title, subtitle, mainColor, accentColor, kanji) {
  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 840" width="600" height="840">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#080c10" />
      <stop offset="60%" stop-color="#121820" />
      <stop offset="100%" stop-color="#050608" />
    </linearGradient>
    <linearGradient id="aura" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${mainColor}" />
      <stop offset="100%" stop-color="${accentColor}" />
    </linearGradient>
    <pattern id="halftone" width="12" height="12" patternUnits="userSpaceOnUse">
      <circle cx="3" cy="3" r="1.5" fill="#fff" opacity="0.06" />
    </pattern>
  </defs>
  <rect width="600" height="840" fill="url(#bg)" />
  <rect width="600" height="840" fill="url(#halftone)" />

  <!-- Background dramatic shapes -->
  <circle cx="300" cy="360" r="220" fill="${mainColor}" opacity="0.14" />
  <circle cx="300" cy="360" r="160" fill="none" stroke="${accentColor}" stroke-width="6" opacity="0.3" stroke-dasharray="16 10" />

  <!-- Huge Kanji Silhouette -->
  <text x="300" y="430" font-family="'Arial Black', sans-serif" font-size="280" font-weight="900" fill="#ffffff" opacity="0.04" text-anchor="middle">${kanji}</text>

  <!-- Dynamic Slash Lines -->
  <line x1="50" y1="120" x2="550" y2="600" stroke="${mainColor}" stroke-width="8" opacity="0.4" />
  <line x1="550" y1="160" x2="80" y2="620" stroke="${accentColor}" stroke-width="5" opacity="0.35" />

  <!-- Character Silhouette Aura -->
  <path d="M260,240 C280,210 320,210 340,240 C370,290 390,360 410,480 L190,480 C210,360 230,290 260,240 Z" fill="url(#aura)" opacity="0.75" />
  <!-- Glowing Eye / Energy spark -->
  <circle cx="285" cy="270" r="6" fill="#ffffff" />
  <circle cx="315" cy="270" r="6" fill="#ffffff" />
  <line x1="285" y1="270" x2="230" y2="250" stroke="#fff" stroke-width="3" opacity="0.8" />
  <line x1="315" y1="270" x2="370" y2="250" stroke="#fff" stroke-width="3" opacity="0.8" />

  <!-- Top Badges -->
  <rect x="40" y="40" width="130" height="30" rx="6" fill="#080a0d" stroke="${mainColor}" stroke-width="2" />
  <text x="105" y="60" font-family="sans-serif" font-weight="900" font-size="12" fill="${mainColor}" text-anchor="middle">ORIGINAL</text>

  <rect x="430" y="40" width="130" height="30" rx="6" fill="#ffe000" />
  <text x="495" y="60" font-family="sans-serif" font-weight="900" font-size="12" fill="#111" text-anchor="middle">HINGLISH</text>

  <!-- Title Bottom Card -->
  <rect x="30" y="620" width="540" height="180" rx="16" fill="#0b0e12" stroke="#252d36" stroke-width="2" />
  <text x="60" y="680" font-family="'Barlow Condensed', 'Arial Black', sans-serif" font-size="44" font-weight="900" fill="#ffffff">${title.toUpperCase()}</text>
  <text x="60" y="720" font-family="sans-serif" font-size="18" font-weight="700" fill="${mainColor}">${subtitle}</text>
  <text x="60" y="755" font-family="sans-serif" font-size="14" fill="#8f97a1">AWSK_EDITZ MANGA UNIVERSE · CHAPTER AVAILABLE</text>
</svg>
`;
}

// 4. Animation Preview SVG
const animPreviewSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540" width="960" height="540">
  <defs>
    <linearGradient id="aBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0c070e" />
      <stop offset="50%" stop-color="#151b24" />
      <stop offset="100%" stop-color="#040608" />
    </linearGradient>
  </defs>
  <rect width="960" height="540" fill="url(#aBg)" />
  <!-- Cinematic Sparks & Lightning -->
  <line x1="120" y1="80" x2="840" y2="460" stroke="#ff3b30" stroke-width="4" opacity="0.4" />
  <line x1="840" y1="100" x2="180" y2="440" stroke="#ffe000" stroke-width="4" opacity="0.3" />
  <circle cx="480" cy="270" r="140" fill="#ffe000" opacity="0.08" />
  
  <!-- Big Play Button Center -->
  <circle cx="480" cy="270" r="54" fill="#080a0ecc" stroke="#ffffff" stroke-width="3" />
  <polygon points="470,248 502,270 470,292" fill="#ffe000" />

  <text x="60" y="460" font-family="'Barlow Condensed', 'Arial Black', sans-serif" font-size="42" font-weight="900" fill="#ffffff">THE LAST BREATH</text>
  <text x="60" y="495" font-family="sans-serif" font-size="16" font-weight="700" fill="#ffe000">OFFICIAL FAN ANIMATION CONCEPT TRAILER</text>
</svg>
`;

async function buildAll() {
  // Write SVGs
  fs.writeFileSync(path.join(outDir, 'app-icon.svg'), appIconSvg);
  fs.writeFileSync(path.join(outDir, 'hero-banner.svg'), heroBannerSvg);
  fs.writeFileSync(path.join(outDir, 'manga-shadow-sun.svg'), createMangaCoverSvg('Shadows of the Last Sun', 'Dark Fantasy · Action', '#00e5ff', '#2979ff', '影'));
  fs.writeFileSync(path.join(outDir, 'manga-crimson.svg'), createMangaCoverSvg('The Crimson Breathing', 'Action · Flame Sword', '#ff3b30', '#ff9100', '炎'));
  fs.writeFileSync(path.join(outDir, 'animation-preview.svg'), animPreviewSvg);

  // Generate PNGs using Sharp
  await sharp(Buffer.from(appIconSvg)).resize(192, 192).png().toFile(path.join(outDir, 'app-icon-192.png'));
  await sharp(Buffer.from(appIconSvg)).resize(512, 512).png().toFile(path.join(outDir, 'app-icon-512.png'));
  // Maskable icon with 15% inner padding
  await sharp(Buffer.from(appIconSvg)).resize(420, 420).extend({
    top: 46, bottom: 46, left: 46, right: 46,
    background: '#0a0d11'
  }).resize(512, 512).png().toFile(path.join(outDir, 'app-icon-maskable-512.png'));

  // Also apple-touch-icon
  await sharp(Buffer.from(appIconSvg)).resize(180, 180).png().toFile(path.join(outDir, 'apple-touch-icon.png'));

  // Raster image fallbacks
  await sharp(Buffer.from(heroBannerSvg)).resize(1400, 480).png().toFile(path.join(outDir, 'hero-banner.png'));
  await sharp(Buffer.from(createMangaCoverSvg('Shadows of the Last Sun', 'Dark Fantasy · Action', '#00e5ff', '#2979ff', '影'))).resize(600, 840).jpeg({ quality: 90 }).toFile(path.join(outDir, 'manga-shadow-sun.jpg'));
  await sharp(Buffer.from(createMangaCoverSvg('The Crimson Breathing', 'Action · Flame Sword', '#ff3b30', '#ff9100', '炎'))).resize(600, 840).jpeg({ quality: 90 }).toFile(path.join(outDir, 'manga-crimson.jpg'));
  await sharp(Buffer.from(animPreviewSvg)).resize(960, 540).jpeg({ quality: 90 }).toFile(path.join(outDir, 'animation-preview.jpg'));

  // Mascot logos
  await sharp(Buffer.from(appIconSvg)).resize(256, 256).png().toFile(path.join(outDir, 'mascot-logo.png'));
  await sharp(Buffer.from(appIconSvg)).resize(256, 256).png().toFile(path.join(outDir, 'mascot-alt.png'));

  console.log('Successfully generated all artwork and PWA icons in /public/assets');
}

buildAll().catch(err => {
  console.error(err);
  process.exit(1);
});
