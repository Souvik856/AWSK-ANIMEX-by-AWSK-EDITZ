import { Manga, Chapter, AnimationProject, AnimeEdit, SiteSettings, NewsPost } from '../types';

export const INITIAL_SITE_SETTINGS: SiteSettings = {
  siteTitle: "AWSK ANIMEX",
  brandSubtext: "Powered by AWSK_EDITZ",
  heroTitle: "BEYOND ANIME. BEYOND IMAGINATION.",
  heroSubtitle: "Hinglish manga, original worlds, fan-made animations and edits made for anime fans.",
  hinglishTagline: "Har Kahani Mein Ek Nayi Duniya.",
  heroBannerUrl: "/assets/hero-banner.png",
  editorName: "Souvik Deb",
  contactEmail: "ryuk83349@gmail.com",
  youtubeUrl: "https://youtube.com/@awskedits012/community?si=YB92B6EqMmW2-ApB",
  instagramUrl: "https://www.instagram.com/awsk_editz?igsh=MWt5ODc2Y2VqcXE4bg==",
  subscribersCount: "4,230+ and growing",
  announcement: "✦ AWSK ANIMEX — Powered by AWSK_EDITZ · Har Kahani Mein Ek Nayi Duniya",
  updatedAt: new Date().toISOString()
};

export const INITIAL_NEWS: NewsPost[] = [
  {
    id: "news-1",
    title: "Shadow's of the Last Sun - Ch 01 Released",
    category: "New Manga Chapter",
    content: "Arin awakens his forgotten shadow powers in the ashes. Read the debut Hinglish chapter now!",
    linkUrl: "#manga",
    imageUrl: "/assets/manga-shadow-sun.jpg",
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    id: "news-2",
    title: "The Last Breath (Concept Trailer) Live",
    category: "New Animation",
    content: "Fan-made animation project spotlight with Sakuga particle physics and cinematic choreography.",
    linkUrl: "#animations",
    imageUrl: "/assets/animation-preview.jpg",
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString()
  },
  {
    id: "news-3",
    title: "Demon Within (Action Shorts Dropped)",
    category: "New Edit",
    content: "High adrenaline 4K edit cut released on our official YouTube Shorts channel.",
    linkUrl: "#edits",
    imageUrl: "/assets/manga-crimson.jpg",
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString()
  },
  {
    id: "news-4",
    title: "The Moon Breathing (Part 1) Story Announced",
    category: "New Story",
    content: "Original concept exploring the ancient dual breathing style in the hidden realm.",
    linkUrl: "#universe",
    imageUrl: "/assets/manga-shadow-sun.jpg",
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
  }
];

export const INITIAL_MANGA: Manga[] = [
  {
    id: "shadows-of-the-last-sun",
    title: "Shadows of the Last Sun",
    slug: "shadows-of-the-last-sun",
    description: "Jokhon prithibi andhokare dube jay, ek bhule jawa shokti abar jege othe. Arin's journey through a fallen world to reclaim the lost light and face ancient demons that lurk beneath the ashes.",
    coverUrl: "/assets/manga-shadow-sun.jpg",
    status: "ongoing",
    type: "original",
    genres: ["Action", "Dark Fantasy", "Adventure"],
    author: "AWSK Universe",
    editor: "Souvik Deb",
    totalChapters: 1,
    featured: true,
    order: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "the-crimson-breathing",
    title: "The Crimson Breathing",
    slug: "the-crimson-breathing",
    description: "Ek notun warrior, ek forbidden technique, ar ekta past ja keu mone rakhte chay na. Ryo unleashes the crimson strike against relentless enemies in a world that fears his power.",
    coverUrl: "/assets/manga-crimson.jpg",
    status: "ongoing",
    type: "original",
    genres: ["Action", "Fantasy", "Martial Arts"],
    author: "AWSK Universe",
    editor: "Souvik Deb",
    totalChapters: 3,
    featured: true,
    order: 2,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "reborn-as-a-warrior",
    title: "Reborn as a Warrior",
    slug: "reborn-as-a-warrior",
    description: "A new journey begins. Reincarnated with memories of the previous grand war, our protagonist must awaken the dormant dragon bloodline before the royal empire collapses into civil unrest.",
    coverUrl: "/assets/manga-shadow-sun.jpg",
    status: "ongoing",
    type: "original",
    genres: ["Adventure", "Supernatural", "Isekai"],
    author: "AWSK Universe",
    editor: "Souvik Deb",
    totalChapters: 2,
    featured: false,
    order: 3,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "the-forgotten-clan",
    title: "The Forgotten Clan",
    slug: "the-forgotten-clan",
    description: "Gaon-er purono archive-e ekta naam abar dekha gelo—emon ekta clan, jar existence shobai bhule gechhilo. Kintu seal-ta bhangar por theke raat-e keu ekjon tar naam dhore dakchhe.",
    coverUrl: "/assets/manga-crimson.jpg",
    status: "ongoing",
    type: "fan-made",
    genres: ["Mystery", "Action", "Ninja"],
    author: "AWSK Universe",
    editor: "Souvik Deb",
    totalChapters: 1,
    featured: false,
    order: 4,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_CHAPTERS: Chapter[] = [
  {
    id: "shadows-ch-1",
    mangaId: "shadows-of-the-last-sun",
    mangaTitle: "Shadows of the Last Sun",
    chapterNumber: 1,
    title: "Chapter 01: Awakening in the Ashes",
    hinglishText: `Raat-er akash-e shesh alo-ta jokhon nibhe gelo, Arin bujhte parlo—tar duniya ar ager moto nei.

Dur theke ekta awaj elo. “Jodi surjo fire pete chao, tahole nijer bhoy-er shamne darate hobe.”

Arin tar haat bondho korlo. Tar moddhe je shokti bohu bochor dhore ghumochhilo, sheta prothombar jege uthlo. Tar shorire kalo r nil agun jole uthlo.

“Ami ar palabo na,” Arin mukh tule bollo. “Je andhokar amar shobcheye priyo jinish kere niyechhe, aaj theke shei andhokar-i amar ostro hobe.”

Akash-e megher garo chhaya aro neme elo. Paharer dhale dariye thaka chhaya-ta ebar heshe uthlo.

“Dekha jak, tumi koto dur jete paro, Last Sun-er shesh uttoradhikari...”`,
    pages: [],
    status: "published",
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "crimson-ch-3",
    mangaId: "the-crimson-breathing",
    mangaTitle: "The Crimson Breathing",
    chapterNumber: 3,
    title: "Chapter 03: The Blood Moon Strike",
    hinglishText: `Paharer opor lal alo jole uthlo. Ryo janto, ei technique use korle tar nijer shorir-o tar dam chaibe.

“Power mane sudhu jeta tumi destroy korte paro ta noy,” tar mentor bolechhilo, “power mane ki protect korte parbe.”

Ryo chokh bondho korlo. Ebar tar shwas-er shobdo thik aguner moto shonachhe. Crimson breathing: Form Three—Rising Eclipse!

Tarpor prothom crimson strike andhokar kete beriye elo. Shat-jon shatru ek poloke thambiye gelo.

“Eita sudhu shuru,” Ryo tar katana khap-e rakhlo.`,
    pages: [],
    status: "published",
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "warrior-ch-2",
    mangaId: "reborn-as-a-warrior",
    mangaTitle: "Reborn as a Warrior",
    chapterNumber: 2,
    title: "Chapter 02: Broken Seals",
    hinglishText: `Notun shorir, purono smriti. Jokhon shobai bhabchhe ami shobar cheye durbol shikkharthi, tokhon amar rokte purono yuddher rahasya jagte shuru korechhe.

Academy-r trial arena-te shobai chechye uthlo. "Ei cheleta ki pagol hoye gechhe? Rank 1 champion ke challenge korche?"

Ami shanto bhabe hashlam. "Shotti ta hocche, rank 1 ekhono ashol yoddha dekheni."`,
    pages: [],
    status: "published",
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "clan-ch-1",
    mangaId: "the-forgotten-clan",
    mangaTitle: "The Forgotten Clan",
    chapterNumber: 1,
    title: "Chapter 01: Whispers of the Past",
    hinglishText: `Gaon-er purono archive-e ekta naam abar dekha gelo—emon ekta clan, jar existence shobai bhule gechhilo.

Kintu seal-ta bhangar por theke raat-e keu ekjon tar naam dhore dakchhe.

Kono manusher awaj noy, borong ekta shoktishali aatma jar shongrakhon kora hoyechhilo paharer gohine. "Tomar rokt-e amader clan-er daag ache..."`,
    pages: [],
    status: "published",
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_ANIMATIONS: AnimationProject[] = [
  {
    id: "the-last-breath-trailer",
    title: "The Last Breath (Concept Trailer)",
    subtitle: "PROJECT SPOTLIGHT",
    description: "Ek original fan-animation concept. Full episode coming soon with high-intensity Sakuga animation, fluid frame pacing, and custom audio mixing.",
    youtubeUrl: "https://www.youtube.com/",
    thumbnailUrl: "/assets/animation-preview.jpg",
    duration: "PREVIEW",
    featured: true,
    createdAt: new Date().toISOString()
  }
];

export const INITIAL_EDITS: AnimeEdit[] = [
  {
    id: "edit-1",
    title: "It's Not Over Yet",
    category: "Anime Edit · Shorts",
    platform: "youtube",
    videoUrl: "https://www.youtube.com/",
    thumbnailUrl: "/assets/manga-crimson.jpg",
    duration: "0:32",
    order: 1
  },
  {
    id: "edit-2",
    title: "Rise Again",
    category: "Action Edit · Shorts",
    platform: "youtube",
    videoUrl: "https://www.youtube.com/",
    thumbnailUrl: "/assets/manga-shadow-sun.jpg",
    duration: "0:41",
    order: 2
  },
  {
    id: "edit-3",
    title: "Beyond Limits",
    category: "Reels · Edit",
    platform: "instagram",
    videoUrl: "https://www.instagram.com/",
    thumbnailUrl: "/assets/animation-preview.jpg",
    duration: "0:38",
    order: 3
  },
  {
    id: "edit-4",
    title: "Broken But Strong",
    category: "Anime Edit · Shorts",
    platform: "youtube",
    videoUrl: "https://www.youtube.com/",
    thumbnailUrl: "/assets/manga-crimson.jpg",
    duration: "0:45",
    order: 4
  },
  {
    id: "edit-5",
    title: "The Real Hero",
    category: "Action Edit · Shorts",
    platform: "youtube",
    videoUrl: "https://www.youtube.com/",
    thumbnailUrl: "/assets/manga-shadow-sun.jpg",
    duration: "0:37",
    order: 5
  }
];
