import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider, BOOTSTRAP_ADMIN_EMAIL } from '../firebase';

interface AdminSession {
  email: string;
  role: 'superadmin' | 'editor';
  name: string;
  token: string;
  timestamp: number;
}

interface AuthContextType {
  user: User | null;
  adminSession: AdminSession | null;
  loading: boolean;
  isAdmin: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithCredentials: (email: string, pass: string) => { success: boolean; error?: string };
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  adminSession: null,
  loading: true,
  isAdmin: false,
  loginWithGoogle: async () => {},
  loginWithCredentials: () => ({ success: false }),
  logout: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [adminSession, setAdminSession] = useState<AdminSession | null>(() => {
    try {
      const stored = localStorage.getItem('awsk_admin_session');
      if (stored) {
        const parsed = JSON.parse(stored) as AdminSession;
        // Verify token validity
        if (
          (parsed.email === 'debs4807@gmail.com' && parsed.token === 'token_debs_740706') ||
          (parsed.email === 'ryuk83349@gmail.com' && parsed.token === 'token_ryuk_995760')
        ) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return null;
  });
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState<boolean>(() => Boolean(adminSession));

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const email = currentUser.email?.toLowerCase();
        if (email === BOOTSTRAP_ADMIN_EMAIL.toLowerCase() || email === 'ryuk83349@gmail.com') {
          setIsAdmin(true);
        } else {
          try {
            const adminDoc = await getDoc(doc(db, 'admins', currentUser.uid));
            setIsAdmin(adminDoc.exists() || Boolean(adminSession));
          } catch {
            setIsAdmin(Boolean(adminSession));
          }
        }
      } else {
        setIsAdmin(Boolean(adminSession));
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [adminSession]);

  // Email and password verification
  const loginWithCredentials = (emailInput: string, passwordInput: string) => {
    const email = emailInput.trim().toLowerCase();
    const password = passwordInput.trim();

    if (email === 'debs4807@gmail.com' && password === '740706') {
      const session: AdminSession = {
        email: 'debs4807@gmail.com',
        name: 'Souvik Deb (Lead Editor)',
        role: 'superadmin',
        token: 'token_debs_740706',
        timestamp: Date.now()
      };
      setAdminSession(session);
      setIsAdmin(true);
      localStorage.setItem('awsk_admin_session', JSON.stringify(session));
      return { success: true };
    }

    if (email === 'ryuk83349@gmail.com' && password === '995760') {
      const session: AdminSession = {
        email: 'ryuk83349@gmail.com',
        name: 'Editorial Business Admin',
        role: 'superadmin',
        token: 'token_ryuk_995760',
        timestamp: Date.now()
      };
      setAdminSession(session);
      setIsAdmin(true);
      localStorage.setItem('awsk_admin_session', JSON.stringify(session));
      return { success: true };
    }

    return {
      success: false,
      error: 'Access Denied: Incorrect email or password. Only authorized editors can access the admin setup.'
    };
  };

  const loginWithGoogle = async () => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const email = cred.user.email?.toLowerCase();
      if (email === BOOTSTRAP_ADMIN_EMAIL.toLowerCase() || email === 'ryuk83349@gmail.com') {
        setIsAdmin(true);
      }
    } catch (error) {
      console.error('Google Sign-In error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      setAdminSession(null);
      setIsAdmin(false);
      localStorage.removeItem('awsk_admin_session');
      await signOut(auth);
    } catch (error) {
      console.error('Sign-Out error:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        adminSession,
        loading,
        isAdmin,
        loginWithGoogle,
        loginWithCredentials,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
