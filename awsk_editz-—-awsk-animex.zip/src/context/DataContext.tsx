import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  deleteDoc,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Manga,
  Chapter,
  AnimationProject,
  AnimeEdit,
  SiteSettings,
  NewsPost,
  BookmarkItem,
  ReadingHistoryItem
} from '../types';
import {
  INITIAL_MANGA,
  INITIAL_CHAPTERS,
  INITIAL_ANIMATIONS,
  INITIAL_EDITS,
  INITIAL_SITE_SETTINGS,
  INITIAL_NEWS
} from '../data/initialData';
import { useAuth } from './AuthContext';

interface DataContextType {
  mangaList: Manga[];
  chaptersList: Chapter[];
  animationsList: AnimationProject[];
  editsList: AnimeEdit[];
  newsList: NewsPost[];
  siteSettings: SiteSettings;
  bookmarks: BookmarkItem[];
  readingHistory: ReadingHistoryItem[];
  loading: boolean;
  isDbConnected: boolean;
  toggleBookmark: (manga: Manga, lastChapter?: number) => Promise<void>;
  isBookmarked: (mangaId: string) => boolean;
  recordReadingHistory: (mangaId: string, chapterId: string, chapterNumber: number) => Promise<void>;
  // Admin actions
  saveManga: (manga: Manga) => Promise<void>;
  deleteManga: (mangaId: string) => Promise<void>;
  saveChapter: (chapter: Chapter) => Promise<void>;
  deleteChapter: (chapterId: string) => Promise<void>;
  saveAnimation: (animation: AnimationProject) => Promise<void>;
  deleteAnimation: (animId: string) => Promise<void>;
  saveEdit: (edit: AnimeEdit) => Promise<void>;
  deleteEdit: (editId: string) => Promise<void>;
  saveNewsPost: (news: NewsPost) => Promise<void>;
  deleteNewsPost: (newsId: string) => Promise<void>;
  saveSiteSettings: (settings: SiteSettings) => Promise<void>;
  seedInitialDataToFirestore: () => Promise<void>;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [mangaList, setMangaList] = useState<Manga[]>(INITIAL_MANGA);
  const [chaptersList, setChaptersList] = useState<Chapter[]>(INITIAL_CHAPTERS);
  const [animationsList, setAnimationsList] = useState<AnimationProject[]>(INITIAL_ANIMATIONS);
  const [editsList, setEditsList] = useState<AnimeEdit[]>(INITIAL_EDITS);
  const [newsList, setNewsList] = useState<NewsPost[]>(INITIAL_NEWS);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(INITIAL_SITE_SETTINGS);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => {
    try {
      const saved = localStorage.getItem('awsk_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [readingHistory, setReadingHistory] = useState<ReadingHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('awsk_reading_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [loading, setLoading] = useState(true);
  const [isDbConnected, setIsDbConnected] = useState(false);

  // 1. Subscribe to Firestore Collections with fallback
  useEffect(() => {
    const unsubs: (() => void)[] = [];

    try {
      // Manga
      const unsubManga = onSnapshot(
        collection(db, 'manga'),
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Manga));
            items.sort((a, b) => (a.order || 0) - (b.order || 0));
            setMangaList(items);
            setIsDbConnected(true);
          } else {
            // If empty in Firestore, populate initial canonical data so it persists permanently
            console.log('Firestore manga collection empty, auto-populating initial universe...');
            INITIAL_MANGA.forEach(async (m) => {
              try {
                await setDoc(doc(db, 'manga', m.id), m);
              } catch {
                // Ignore silent seed error if rules restrict unauthenticated public write
              }
            });
          }
        },
        (error) => {
          console.warn('Firestore Manga read notice:', error.message);
        }
      );
      unsubs.push(unsubManga);

      // Chapters
      const unsubChapters = onSnapshot(
        collection(db, 'chapters'),
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Chapter));
            items.sort((a, b) => b.chapterNumber - a.chapterNumber);
            setChaptersList(items);
          } else {
            INITIAL_CHAPTERS.forEach(async (c) => {
              try {
                await setDoc(doc(db, 'chapters', c.id), c);
              } catch {
                // Fallback handled
              }
            });
          }
        },
        (error) => {
          console.warn('Firestore Chapters read notice:', error.message);
        }
      );
      unsubs.push(unsubChapters);

      // Animations
      const unsubAnimations = onSnapshot(
        collection(db, 'animations'),
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as AnimationProject));
            setAnimationsList(items);
          } else {
            INITIAL_ANIMATIONS.forEach(async (a) => {
              try {
                await setDoc(doc(db, 'animations', a.id), a);
              } catch {
                // Fallback handled
              }
            });
          }
        },
        (error) => {
          console.warn('Firestore Animations read notice:', error.message);
        }
      );
      unsubs.push(unsubAnimations);

      // Edits
      const unsubEdits = onSnapshot(
        collection(db, 'edits'),
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as AnimeEdit));
            items.sort((a, b) => (a.order || 0) - (b.order || 0));
            setEditsList(items);
          } else {
            INITIAL_EDITS.forEach(async (e) => {
              try {
                await setDoc(doc(db, 'edits', e.id), e);
              } catch {
                // Fallback handled
              }
            });
          }
        },
        (error) => {
          console.warn('Firestore Edits read notice:', error.message);
        }
      );
      unsubs.push(unsubEdits);

      // News & Community Updates
      const unsubNews = onSnapshot(
        collection(db, 'news'),
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as NewsPost));
            items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setNewsList(items);
          } else {
            INITIAL_NEWS.forEach(async (n) => {
              try {
                await setDoc(doc(db, 'news', n.id), n);
              } catch {
                // Fallback handled
              }
            });
          }
        },
        (error) => {
          console.warn('Firestore News read notice:', error.message);
        }
      );
      unsubs.push(unsubNews);

      // Site Settings
      const unsubSettings = onSnapshot(
        doc(db, 'siteSettings', 'general'),
        (docSnap) => {
          if (docSnap.exists()) {
            setSiteSettings(docSnap.data() as SiteSettings);
          } else {
            setDoc(doc(db, 'siteSettings', 'general'), INITIAL_SITE_SETTINGS).catch(() => {});
          }
        },
        (error) => {
          console.warn('Firestore Site Settings read notice:', error.message);
        }
      );
      unsubs.push(unsubSettings);
    } catch (err) {
      console.warn('Firestore listeners error:', err);
    } finally {
      setLoading(false);
    }

    return () => {
      unsubs.forEach((unsub) => unsub());
    };
  }, []);

  // 2. Sync Bookmarks for Authenticated User
  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(
      collection(db, 'users', user.uid, 'bookmarks'),
      (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as BookmarkItem));
          setBookmarks(items);
          localStorage.setItem('awsk_bookmarks', JSON.stringify(items));
        }
      },
      (error) => {
        console.warn('Bookmarks listener notice:', error.message);
      }
    );
    return () => unsub();
  }, [user]);

  // Bookmarking handler
  const toggleBookmark = async (manga: Manga, lastChapter = 1) => {
    const exists = bookmarks.some((b) => b.mangaId === manga.id);
    let nextBookmarks: BookmarkItem[];

    if (exists) {
      nextBookmarks = bookmarks.filter((b) => b.mangaId !== manga.id);
      if (user) {
        try {
          await deleteDoc(doc(db, 'users', user.uid, 'bookmarks', manga.id));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `users/${user.uid}/bookmarks/${manga.id}`);
        }
      }
    } else {
      const newItem: BookmarkItem = {
        id: manga.id,
        mangaId: manga.id,
        mangaTitle: manga.title,
        coverUrl: manga.coverUrl,
        lastReadChapter: lastChapter,
        savedAt: new Date().toISOString()
      };
      nextBookmarks = [newItem, ...bookmarks];
      if (user) {
        try {
          await setDoc(doc(db, 'users', user.uid, 'bookmarks', manga.id), newItem);
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/bookmarks/${manga.id}`);
        }
      }
    }

    setBookmarks(nextBookmarks);
    localStorage.setItem('awsk_bookmarks', JSON.stringify(nextBookmarks));
  };

  const isBookmarked = (mangaId: string) => {
    return bookmarks.some((b) => b.mangaId === mangaId);
  };

  const recordReadingHistory = async (mangaId: string, chapterId: string, chapterNumber: number) => {
    const item: ReadingHistoryItem = {
      mangaId,
      chapterId,
      chapterNumber,
      readAt: new Date().toISOString()
    };
    const nextHistory = [item, ...readingHistory.filter((h) => h.mangaId !== mangaId)].slice(0, 20);
    setReadingHistory(nextHistory);
    localStorage.setItem('awsk_reading_history', JSON.stringify(nextHistory));
  };

  // Admin CRUD actions
  const saveManga = async (manga: Manga) => {
    try {
      await setDoc(doc(db, 'manga', manga.id), manga);
      setMangaList((prev) => {
        const filtered = prev.filter((m) => m.id !== manga.id);
        const updated = [...filtered, manga];
        updated.sort((a, b) => (a.order || 0) - (b.order || 0));
        return updated;
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `manga/${manga.id}`);
    }
  };

  const deleteManga = async (mangaId: string) => {
    try {
      await deleteDoc(doc(db, 'manga', mangaId));
      setMangaList((prev) => prev.filter((m) => m.id !== mangaId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `manga/${mangaId}`);
    }
  };

  const saveChapter = async (chapter: Chapter) => {
    try {
      await setDoc(doc(db, 'chapters', chapter.id), chapter);
      setChaptersList((prev) => {
        const filtered = prev.filter((c) => c.id !== chapter.id);
        const updated = [...filtered, chapter];
        updated.sort((a, b) => b.chapterNumber - a.chapterNumber);
        return updated;
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `chapters/${chapter.id}`);
    }
  };

  const deleteChapter = async (chapterId: string) => {
    try {
      await deleteDoc(doc(db, 'chapters', chapterId));
      setChaptersList((prev) => prev.filter((c) => c.id !== chapterId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `chapters/${chapterId}`);
    }
  };

  const saveAnimation = async (anim: AnimationProject) => {
    try {
      await setDoc(doc(db, 'animations', anim.id), anim);
      setAnimationsList((prev) => {
        const filtered = prev.filter((a) => a.id !== anim.id);
        return [...filtered, anim];
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `animations/${anim.id}`);
    }
  };

  const deleteAnimation = async (animId: string) => {
    try {
      await deleteDoc(doc(db, 'animations', animId));
      setAnimationsList((prev) => prev.filter((a) => a.id !== animId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `animations/${animId}`);
    }
  };

  const saveEdit = async (edit: AnimeEdit) => {
    try {
      await setDoc(doc(db, 'edits', edit.id), edit);
      setEditsList((prev) => {
        const filtered = prev.filter((e) => e.id !== edit.id);
        const updated = [...filtered, edit];
        updated.sort((a, b) => (a.order || 0) - (b.order || 0));
        return updated;
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `edits/${edit.id}`);
    }
  };

  const deleteEdit = async (editId: string) => {
    try {
      await deleteDoc(doc(db, 'edits', editId));
      setEditsList((prev) => prev.filter((e) => e.id !== editId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `edits/${editId}`);
    }
  };

  const saveNewsPost = async (news: NewsPost) => {
    try {
      await setDoc(doc(db, 'news', news.id), news);
      setNewsList((prev) => {
        const filtered = prev.filter((n) => n.id !== news.id);
        const updated = [news, ...filtered];
        updated.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return updated;
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `news/${news.id}`);
    }
  };

  const deleteNewsPost = async (newsId: string) => {
    try {
      await deleteDoc(doc(db, 'news', newsId));
      setNewsList((prev) => prev.filter((n) => n.id !== newsId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `news/${newsId}`);
    }
  };

  const saveSiteSettings = async (settings: SiteSettings) => {
    try {
      await setDoc(doc(db, 'siteSettings', 'general'), settings);
      setSiteSettings(settings);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'siteSettings/general');
    }
  };

  const seedInitialDataToFirestore = async () => {
    try {
      const batch = writeBatch(db);

      // Seed Site Settings
      batch.set(doc(db, 'siteSettings', 'general'), INITIAL_SITE_SETTINGS);

      // Seed Manga
      INITIAL_MANGA.forEach((m) => {
        batch.set(doc(db, 'manga', m.id), m);
      });

      // Seed Chapters
      INITIAL_CHAPTERS.forEach((c) => {
        batch.set(doc(db, 'chapters', c.id), c);
      });

      // Seed Animations
      INITIAL_ANIMATIONS.forEach((a) => {
        batch.set(doc(db, 'animations', a.id), a);
      });

      // Seed Edits
      INITIAL_EDITS.forEach((e) => {
        batch.set(doc(db, 'edits', e.id), e);
      });

      // Seed News Posts
      INITIAL_NEWS.forEach((n) => {
        batch.set(doc(db, 'news', n.id), n);
      });

      await batch.commit();
      setIsDbConnected(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'seedBatch');
    }
  };

  return (
    <DataContext.Provider
      value={{
        mangaList,
        chaptersList,
        animationsList,
        editsList,
        newsList,
        siteSettings,
        bookmarks,
        readingHistory,
        loading,
        isDbConnected,
        toggleBookmark,
        isBookmarked,
        recordReadingHistory,
        saveManga,
        deleteManga,
        saveChapter,
        deleteChapter,
        saveAnimation,
        deleteAnimation,
        saveEdit,
        deleteEdit,
        saveNewsPost,
        deleteNewsPost,
        saveSiteSettings,
        seedInitialDataToFirestore
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
};
