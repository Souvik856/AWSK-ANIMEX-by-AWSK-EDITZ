import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FeaturedManga } from './components/FeaturedManga';
import { LatestChapters } from './components/LatestChapters';
import { UniverseSection } from './components/UniverseSection';
import { AnimationsShowcase } from './components/AnimationsShowcase';
import { EditsShowcase } from './components/EditsShowcase';
import { CommunitySection } from './components/CommunitySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { MangaReaderModal } from './components/MangaReaderModal';
import { MangaDetailModal } from './components/MangaDetailModal';
import { BookmarksModal } from './components/BookmarksModal';
import { VideoModal } from './components/VideoModal';
import { PrivacyModal } from './components/PrivacyModal';
import { AdminDashboard } from './components/AdminDashboard';
import { OfflineIndicator, PWAUpdateToast } from './components/OfflineIndicator';
import { Manga, Chapter, AnimationProject, AnimeEdit } from './types';
import { Sparkles } from 'lucide-react';

const MainApp: React.FC = () => {
  const { mangaList, chaptersList, animationsList, editsList, siteSettings } = useData();

  // Search query state
  const [searchQuery, setSearchQuery] = useState('');

  // Modal states
  const [readingManga, setReadingManga] = useState<Manga | null>(null);
  const [readingChapter, setReadingChapter] = useState<Chapter | null>(null);
  const [detailManga, setDetailManga] = useState<Manga | null>(null);
  const [activeVideo, setActiveVideo] = useState<{ title: string; url: string } | null>(null);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);

  const handleOpenReader = (manga: Manga, chapter?: Chapter) => {
    setReadingManga(manga);
    setReadingChapter(chapter || null);
  };

  return (
    <div className="relative min-h-screen bg-[#07090b] text-[#f5f6f7]">
      {/* Ambient background glows */}
      <div className="ambient-glow-yellow top-[20%] -left-[200px]" />
      <div className="ambient-glow-red top-[60%] -right-[220px]" />

      {/* Global Announcement Banner if active */}
      {siteSettings.announcement && (
        <div className="bg-gradient-to-r from-[#ffe000] via-[#ffb300] to-[#ff3b31] py-1 px-4 text-center text-[10px] md:text-xs font-black text-black tracking-wider uppercase flex items-center justify-center gap-2">
          <Sparkles className="h-3 w-3 shrink-0" />
          <span>{siteSettings.announcement}</span>
        </div>
      )}

      {/* Sticky Navigation */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenAdmin={() => setShowAdmin(true)}
        onOpenBookmarks={() => setShowBookmarks(true)}
      />

      <main id="home" className="relative z-10">
        {/* Cinematic Hero */}
        <Hero
          onExploreManga={() => {
            const el = document.getElementById('manga');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onWatchProjects={() => {
            const el = document.getElementById('animations');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Featured Manga Series */}
        <FeaturedManga
          mangaList={mangaList}
          onReadManga={(m) => handleOpenReader(m)}
          onOpenDetails={(m) => setDetailManga(m)}
        />

        {/* Latest Chapters & Community Live Updates */}
        <LatestChapters
          mangaList={mangaList}
          chaptersList={chaptersList}
          searchQuery={searchQuery}
          onReadChapter={(m, ch) => handleOpenReader(m, ch)}
          onOpenDetails={(m) => setDetailManga(m)}
        />

        {/* Anime Universe (Original & Fan-made Worlds) */}
        <UniverseSection />

        {/* Fan-made Animations Showcase */}
        <AnimationsShowcase
          animationsList={animationsList}
          onPlayAnimation={(anim) =>
            setActiveVideo({ title: anim.title, url: anim.youtubeUrl })
          }
        />

        {/* Latest Edits & Action Shorts */}
        <EditsShowcase
          editsList={editsList}
          onPlayEdit={(edit) =>
            setActiveVideo({ title: edit.title, url: edit.videoUrl })
          }
        />

        {/* Community & Subscriber Section */}
        <CommunitySection />

        {/* Business Enquiries & Collaboration Contact */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenPrivacy={() => setShowPrivacy(true)}
        onOpenAdmin={() => setShowAdmin(true)}
      />

      {/* MODALS */}
      {/* 1. Manga Reader Modal */}
      {readingManga && (
        <MangaReaderModal
          manga={readingManga}
          initialChapter={readingChapter}
          onClose={() => {
            setReadingManga(null);
            setReadingChapter(null);
          }}
        />
      )}

      {/* 2. Manga Detail Overview Modal */}
      {detailManga && (
        <MangaDetailModal
          manga={detailManga}
          onClose={() => setDetailManga(null)}
          onReadChapter={(m, ch) => {
            setDetailManga(null);
            handleOpenReader(m, ch);
          }}
        />
      )}

      {/* 3. Bookmarks Modal */}
      {showBookmarks && (
        <BookmarksModal
          onClose={() => setShowBookmarks(false)}
          onSelectManga={(m) => handleOpenReader(m)}
        />
      )}

      {/* 4. Video Trailer Player Modal */}
      {activeVideo && (
        <VideoModal
          title={activeVideo.title}
          videoUrl={activeVideo.url}
          onClose={() => setActiveVideo(null)}
        />
      )}

      {/* 5. Privacy & DMCA Modal */}
      {showPrivacy && <PrivacyModal onClose={() => setShowPrivacy(false)} />}

      {/* 6. Admin Dashboard */}
      {showAdmin && <AdminDashboard onClose={() => setShowAdmin(false)} />}

      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Service Worker Update Toast */}
      <PWAUpdateToast />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <MainApp />
      </DataProvider>
    </AuthProvider>
  );
}
