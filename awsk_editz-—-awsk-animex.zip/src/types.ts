export interface Manga {
  id: string;
  title: string;
  slug: string;
  description: string;
  coverUrl: string;
  bannerUrl?: string;
  status: 'ongoing' | 'completed' | 'hiatus';
  type: 'original' | 'fan-made';
  genres: string[];
  author: string;
  editor: string;
  totalChapters: number;
  featured: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  mangaId: string;
  mangaTitle: string;
  chapterNumber: number;
  title: string;
  hinglishText: string;
  pages?: string[]; // Array of comic page image URLs
  status: 'published' | 'draft';
  createdAt: string;
  updatedAt: string;
}

export interface AnimationProject {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  youtubeUrl: string;
  thumbnailUrl: string;
  duration: string;
  featured: boolean;
  category?: string;
  episodeNumber?: number;
  releaseDate?: string;
  createdAt: string;
}

export interface AnimeEdit {
  id: string;
  title: string;
  category: string;
  platform: 'youtube' | 'instagram';
  videoUrl: string;
  thumbnailUrl: string;
  duration: string;
  order: number;
}

export interface SiteSettings {
  siteTitle: string;
  brandSubtext?: string;
  heroTitle: string;
  heroSubtitle: string;
  hinglishTagline?: string;
  heroBannerUrl?: string;
  editorName: string;
  contactEmail: string;
  youtubeUrl: string;
  instagramUrl: string;
  subscribersCount?: string;
  announcement?: string;
  updatedAt: string;
}

export interface NewsPost {
  id: string;
  title: string;
  category: string;
  content: string;
  linkUrl?: string;
  imageUrl?: string;
  createdAt: string;
}

export interface BookmarkItem {
  id: string;
  mangaId: string;
  mangaTitle: string;
  coverUrl?: string;
  lastReadChapter: number;
  savedAt: string;
}

export interface ReadingHistoryItem {
  mangaId: string;
  chapterId: string;
  chapterNumber: number;
  readAt: string;
}
