import React from 'react';
import { useData } from '../context/DataContext';
import { Mail, MessageSquare, Send } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { siteSettings } = useData();

  return (
    <section id="contact" className="mx-auto max-w-7xl px-4 md:px-8 pt-16 pb-12">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-[#20272e] pb-10">
        <div>
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
            LET'S CREATE SOMETHING
          </div>
          <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
            Contact <span className="text-[#ffe000]">AWSK_EDITZ</span>
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-[#aeb5bb] max-w-lg leading-relaxed">
            Collaboration, manga ideas, fan art, animation sponsorships or business enquiries. Managed by Channel Editor <strong>{siteSettings.editorName || "Souvik Deb"}</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <a
            href={`mailto:${siteSettings.contactEmail || "ryuk83349@gmail.com"}`}
            className="flex items-center gap-2 rounded-xl border border-[#48515a] bg-[#0d1115] px-5 py-3 text-xs font-bold text-white hover:border-[#ffe000] hover:text-[#ffe000] transition active:scale-95 shadow-md"
          >
            <Mail className="h-4 w-4 text-[#ffe000]" />
            <span>✉ {siteSettings.contactEmail || "ryuk83349@gmail.com"}</span>
          </a>
        </div>
      </div>
    </section>
  );
};
