import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Manga, Chapter, AnimationProject, AnimeEdit, SiteSettings, NewsPost } from '../types';
import { ref, uploadBytes, getDownloadURL, storage } from '../firebase';
import {
  X,
  Shield,
  BookOpen,
  FileText,
  Video,
  Scissors,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Upload,
  Check,
  Lock,
  KeyRound,
  LogIn,
  LogOut,
  Sparkles,
  Database,
  Newspaper,
  Image as ImageIcon,
  ExternalLink,
  Loader2
} from 'lucide-react';

interface AdminDashboardProps {
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
  const { user, adminSession, isAdmin, loginWithCredentials, loginWithGoogle, logout } = useAuth();
  const {
    mangaList,
    chaptersList,
    animationsList,
    editsList,
    newsList,
    siteSettings,
    saveManga,
    deleteManga,
    saveChapter,
    deleteChapter,
    saveAnimation,
    deleteAnimation,
    saveEdit,
    deleteEdit,
    saveNewsPost,
    deleteNewsPost,
    saveSiteSettings,
    seedInitialDataToFirestore
  } = useData();

  // Login form state
  const [emailInput, setEmailInput] = useState('debs4807@gmail.com');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Tabs: 'manga' | 'chapters' | 'animations' | 'edits' | 'news' | 'images' | 'settings' | 'seed'
  const [activeTab, setActiveTab] = useState<'manga' | 'chapters' | 'animations' | 'edits' | 'news' | 'images' | 'settings' | 'seed'>('manga');
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Entity editing states
  const [editingManga, setEditingManga] = useState<Partial<Manga> | null>(null);
  const [editingChapter, setEditingChapter] = useState<Partial<Chapter> | null>(null);
  const [editingAnimation, setEditingAnimation] = useState<Partial<AnimationProject> | null>(null);
  const [editingEdit, setEditingEdit] = useState<Partial<AnimeEdit> | null>(null);
  const [editingNews, setEditingNews] = useState<Partial<NewsPost> | null>(null);
  const [settingsForm, setSettingsForm] = useState<SiteSettings>(siteSettings);

  // Quick image studio state
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);

  const notify = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMsg({ text, type });
    setTimeout(() => setStatusMsg(null), 3000);
  };

  // Loading & upload states
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgressText, setUploadProgressText] = useState<string>('');

  // Helper: Validate file and upload to Firebase Storage (with high-res Canvas optimization fallback)
  const handleImageFile = async (file: File, callback: (url: string) => void) => {
    // 1. File Type Validation
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      notify('Invalid file format. Please upload JPG, PNG, WEBP, or SVG.', 'error');
      return;
    }

    // 2. File Size Validation (Max 15MB)
    const MAX_SIZE_BYTES = 15 * 1024 * 1024;
    if (file.size > MAX_SIZE_BYTES) {
      notify('File too large. Maximum image file size is 15MB.', 'error');
      return;
    }

    setIsUploading(true);
    setUploadProgressText(`Uploading ${file.name}...`);

    try {
      // Try direct upload to Firebase Storage first
      const fileExt = file.name.split('.').pop() || 'jpg';
      const cleanFileName = `awsk_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
      const storageRef = ref(storage, `uploads/${cleanFileName}`);

      try {
        const uploadResult = await uploadBytes(storageRef, file, {
          contentType: file.type,
          customMetadata: {
            uploadedBy: adminSession?.email || 'admin',
            originalName: file.name
          }
        });
        const downloadUrl = await getDownloadURL(uploadResult.ref);
        callback(downloadUrl);
        notify(`Artwork "${file.name}" uploaded to Cloud Storage!`, 'success');
        setIsUploading(false);
        setUploadProgressText('');
        return;
      } catch (storageErr: unknown) {
        console.warn('Firebase Storage direct upload notice, processing via optimized web asset pipeline:', storageErr);
      }

      // Fallback: High-res Web Canvas optimization (maintains quality, ensures works seamlessly offline/without custom bucket rules)
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 1600;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, w, h);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
            callback(dataUrl);
            notify(`Image "${file.name}" processed and ready!`, 'success');
          }
          setIsUploading(false);
          setUploadProgressText('');
        };
        img.onerror = () => {
          notify('Failed to decode image file.', 'error');
          setIsUploading(false);
          setUploadProgressText('');
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => {
        notify('Failed to read selected file.', 'error');
        setIsUploading(false);
        setUploadProgressText('');
      };
      reader.readAsDataURL(file);
    } catch (err: unknown) {
      notify('Upload error: ' + (err instanceof Error ? err.message : String(err)), 'error');
      setIsUploading(false);
      setUploadProgressText('');
    }
  };

  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const result = loginWithCredentials(emailInput, passwordInput);
    if (!result.success) {
      setLoginError(result.error || 'Access Denied: Invalid credentials.');
    } else {
      notify('Welcome, Editor! Admin Access Granted.');
    }
  };

  // 1. LOCKED GATE: If not verified administrator, show secure Admin Login
  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md">
        <div className="absolute inset-0" onClick={onClose} />
        
        <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-[#ffe00044] bg-[#0c1015] p-6 sm:p-8 text-white shadow-2xl z-10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#ffe00015] border border-[#ffe00040] text-[#ffe000] mb-3">
            <Lock className="h-7 w-7" />
          </div>

          <h3 className="font-heading text-center text-3xl font-black uppercase tracking-tight text-white">
            AWSK_EDITZ <span className="text-[#ffe000]">ADMIN SETUP</span>
          </h3>
          <p className="mt-1 text-center text-xs text-[#8e98a2]">
            Protected Editorial Portal. Enter authorized email and password to manage the whole website.
          </p>

          {loginError && (
            <div className="mt-4 rounded-xl border border-red-500/50 bg-red-500/10 p-3 text-xs text-red-300 flex items-center gap-2">
              <span className="font-bold">⚠️</span>
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleCredentialsSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-[#ffe000] mb-1">
                Editor Email
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="debs4807@gmail.com"
                className="w-full rounded-xl border border-[#303840] bg-[#121820] px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:border-[#ffe000] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-[#ffe000] mb-1">
                Admin Password
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••"
                className="w-full rounded-xl border border-[#303840] bg-[#121820] px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:border-[#ffe000] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="mt-2 w-full flex items-center justify-center gap-2 rounded-xl bg-[#ffe000] py-3 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95 shadow-lg shadow-yellow-500/20"
            >
              <KeyRound className="h-4 w-4" />
              <span>Login to Admin Setup</span>
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-[#1e252c] flex flex-col items-center gap-3">
            <span className="text-[10px] text-[#6a747e] uppercase">or authenticate via Google SSO</span>
            <button
              type="button"
              onClick={loginWithGoogle}
              className="flex items-center gap-2 rounded-xl border border-[#303840] bg-[#12171c] px-4 py-2 text-xs font-bold text-gray-300 hover:border-white hover:text-white transition"
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>Sign in with Google Account</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. VERIFIED ADMIN DASHBOARD: FULL ACCESS
  const activeEmail = adminSession?.email || user?.email || 'debs4807@gmail.com';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/90 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative flex flex-col h-[95vh] w-full max-w-6xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0c1015] shadow-2xl z-10 text-white">
        
        {/* Top Header Bar */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] px-6 py-4 bg-[#0f141b]">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#ffe00020] border border-[#ffe00050] text-[#ffe000]">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-heading text-xl sm:text-2xl font-black uppercase text-white leading-tight">
                  AWSK_EDITZ SETUP &amp; EDITORIAL PORTAL
                </h2>
                <span className="rounded bg-green-500/20 border border-green-500/40 px-2 py-0.5 text-[9px] font-black text-green-400">
                  AUTHENTICATED
                </span>
              </div>
              <span className="text-[11px] text-[#8e98a2]">
                Logged in as: <strong className="text-[#ffe000]">{activeEmail}</strong> · Editor: <strong>{siteSettings.editorName}</strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={logout}
              className="flex items-center gap-1.5 rounded-xl border border-[#303840] bg-[#141a20] px-3 py-1.5 text-xs text-gray-300 hover:text-white hover:border-red-500 transition"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-xl border border-[#303840] text-gray-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Status Toast Banner */}
        {statusMsg && (
          <div className={`px-6 py-2.5 text-xs font-bold flex items-center gap-2 ${
            statusMsg.type === 'success' ? 'bg-[#ffe000] text-black' : 'bg-red-600 text-white'
          }`}>
            <Check className="h-3.5 w-3.5" />
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex shrink-0 overflow-x-auto border-b border-[#222a30] bg-[#090c0f] px-6 py-2.5 gap-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('manga')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'manga' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Mangas ({mangaList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('chapters')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'chapters' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Chapters ({chaptersList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('animations')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'animations' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <Video className="h-3.5 w-3.5" />
            <span>Animations &amp; Trailers ({animationsList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('edits')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'edits' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <Scissors className="h-3.5 w-3.5" />
            <span>Edits &amp; Shorts ({editsList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('news')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'news' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <Newspaper className="h-3.5 w-3.5" />
            <span>News &amp; Updates ({newsList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'settings' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <Settings className="h-3.5 w-3.5" />
            <span>Hole Setup &amp; Socials</span>
          </button>

          <button
            onClick={() => setActiveTab('images')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'images' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <ImageIcon className="h-3.5 w-3.5" />
            <span>Image Studio</span>
          </button>

          <button
            onClick={() => setActiveTab('seed')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 transition ${
              activeTab === 'seed' ? 'bg-[#ffe000] text-black shadow-md' : 'text-[#8e98a2] hover:text-white'
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            <span>DB Seed</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#07090b]">
          
          {/* TAB: MANGAS */}
          {activeTab === 'manga' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-heading text-xl font-bold uppercase text-white">
                    Manga Universe Catalog
                  </h3>
                  <p className="text-xs text-[#8e98a2]">
                    Create new series, upload cover images, and update synopsis &amp; genres.
                  </p>
                </div>
                <button
                  onClick={() =>
                    setEditingManga({
                      id: `manga-${Date.now()}`,
                      title: '',
                      slug: '',
                      description: '',
                      coverUrl: '/assets/manga-shadow-sun.jpg',
                      status: 'ongoing',
                      type: 'original',
                      genres: ['Action', 'Fantasy'],
                      author: 'AWSK Team',
                      editor: siteSettings.editorName || 'Souvik Deb',
                      totalChapters: 1,
                      featured: false,
                      order: mangaList.length + 1
                    })
                  }
                  className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black hover:bg-yellow-300"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>New Manga Series</span>
                </button>
              </div>

              {/* Editing Form */}
              {editingManga && (
                <div className="mb-6 rounded-2xl border border-[#ffe00055] bg-[#0e1319] p-5 space-y-4 shadow-xl">
                  <h4 className="font-bold text-sm text-[#ffe000]">
                    {editingManga.id && mangaList.some((m) => m.id === editingManga.id) ? 'Edit Manga Series' : 'Create New Manga'}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Manga Title</label>
                      <input
                        type="text"
                        value={editingManga.title || ''}
                        onChange={(e) => setEditingManga({ ...editingManga, title: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                        placeholder="e.g. Shadows of the Last Sun"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Slug / Identifier</label>
                      <input
                        type="text"
                        value={editingManga.slug || ''}
                        onChange={(e) => setEditingManga({ ...editingManga, slug: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                        placeholder="e.g. shadows-of-the-last-sun"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Synopsis &amp; Storyline</label>
                    <textarea
                      rows={3}
                      value={editingManga.description || ''}
                      onChange={(e) => setEditingManga({ ...editingManga, description: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Story background and plot summary..."
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Type</label>
                      <select
                        value={editingManga.type || 'original'}
                        onChange={(e) => setEditingManga({ ...editingManga, type: e.target.value as 'original' | 'fan-made' })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      >
                        <option value="original">Original Universe</option>
                        <option value="fan-made">Fan-made Alternate</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Status</label>
                      <select
                        value={editingManga.status || 'ongoing'}
                        onChange={(e) => setEditingManga({ ...editingManga, status: e.target.value as 'ongoing' | 'completed' | 'hiatus' })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      >
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                        <option value="hiatus">Hiatus</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Genres (comma separated)</label>
                      <input
                        type="text"
                        value={editingManga.genres?.join(', ') || ''}
                        onChange={(e) =>
                          setEditingManga({
                            ...editingManga,
                            genres: e.target.value.split(',').map((g) => g.trim()).filter(Boolean)
                          })
                        }
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="Action, Fantasy, Adventure"
                      />
                    </div>
                  </div>

                  {/* Cover Upload */}
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Manga Cover Artwork</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value={editingManga.coverUrl || ''}
                        onChange={(e) => setEditingManga({ ...editingManga, coverUrl: e.target.value })}
                        className="flex-1 rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="Cover image URL or upload image"
                      />
                      <label className="flex items-center gap-1.5 rounded-lg border border-[#303840] bg-[#161d26] px-3.5 py-2 text-xs font-bold cursor-pointer hover:border-[#ffe000] text-gray-200">
                        {isUploading ? <Loader2 className="h-3.5 w-3.5 animate-spin text-[#ffe000]" /> : <Upload className="h-3.5 w-3.5 text-[#ffe000]" />}
                        <span>Upload File</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageFile(file, (url) => setEditingManga({ ...editingManga, coverUrl: url }));
                          }}
                        />
                      </label>
                    </div>
                    {editingManga.coverUrl && (
                      <div className="mt-2 flex items-center gap-2">
                        <img src={editingManga.coverUrl} alt="Cover Preview" className="h-16 w-12 rounded object-cover border border-[#303840]" />
                        <span className="text-[10px] text-gray-400">Cover preview active</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 text-xs text-gray-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingManga.featured || false}
                        onChange={(e) => setEditingManga({ ...editingManga, featured: e.target.checked })}
                      />
                      <span>Feature in Homepage Spotlight</span>
                    </label>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button
                      onClick={() => setEditingManga(null)}
                      className="rounded-xl border border-[#303840] px-4 py-2 text-xs font-bold text-gray-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={async () => {
                        if (!editingManga.title) return alert('Title required');
                        const finalManga: Manga = {
                          id: editingManga.id || `manga-${Date.now()}`,
                          title: editingManga.title || '',
                          slug: editingManga.slug || editingManga.title?.toLowerCase().replace(/\s+/g, '-') || '',
                          description: editingManga.description || '',
                          coverUrl: editingManga.coverUrl || '/assets/manga-shadow-sun.jpg',
                          status: editingManga.status || 'ongoing',
                          type: editingManga.type || 'original',
                          genres: editingManga.genres || ['Action'],
                          author: editingManga.author || 'AWSK Team',
                          editor: editingManga.editor || 'Souvik Deb',
                          totalChapters: editingManga.totalChapters || 1,
                          featured: editingManga.featured || false,
                          order: editingManga.order || 1,
                          createdAt: editingManga.createdAt || new Date().toISOString(),
                          updatedAt: new Date().toISOString()
                        };
                        await saveManga(finalManga);
                        setEditingManga(null);
                        notify('Manga published to Firestore!');
                      }}
                      className="rounded-xl bg-[#ffe000] px-5 py-2 text-xs font-black text-black hover:bg-yellow-300"
                    >
                      Save Manga
                    </button>
                  </div>
                </div>
              )}

              {/* Manga Series List */}
              <div className="rounded-xl border border-[#222a30] bg-[#0c1015] overflow-hidden divide-y divide-[#182028]">
                {mangaList.map((m) => (
                  <div key={m.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <img src={m.coverUrl} alt={m.title} className="h-12 w-9 rounded object-cover" />
                      <div>
                        <strong className="text-sm font-bold text-white">{m.title}</strong>
                        <div className="flex items-center gap-2 text-[10px] text-gray-400">
                          <span className="uppercase text-[#ffe000]">{m.type}</span>
                          <span>·</span>
                          <span>{m.status}</span>
                          <span>·</span>
                          <span>{m.genres?.join(', ')}</span>
                          {m.featured && <span className="text-[#ffe000] font-bold">· FEATURED</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingManga(m)}
                        className="flex items-center gap-1 rounded-lg border border-[#303840] px-3 py-1.5 text-xs text-gray-200 hover:border-[#ffe000]"
                      >
                        <Edit2 className="h-3 w-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={async () => {
                          if (confirm(`Delete "${m.title}"?`)) {
                            await deleteManga(m.id);
                            notify('Manga deleted');
                          }
                        }}
                        className="p-1.5 text-gray-500 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: CHAPTERS */}
          {activeTab === 'chapters' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-heading text-xl font-bold uppercase text-white">
                    Chapter &amp; Comic Panels Publishing
                  </h3>
                  <p className="text-xs text-[#8e98a2]">
                    Write Hinglish dialogue, upload comic page artwork, and manage draft status.
                  </p>
                </div>
                <button
                  onClick={() =>
                    setEditingChapter({
                      id: `ch-${Date.now()}`,
                      mangaId: mangaList[0]?.id || '',
                      mangaTitle: mangaList[0]?.title || '',
                      chapterNumber: (chaptersList.length || 0) + 1,
                      title: '',
                      hinglishText: '',
                      pages: [],
                      status: 'published'
                    })
                  }
                  className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black hover:bg-yellow-300"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Publish Chapter</span>
                </button>
              </div>

              {/* Editing Chapter */}
              {editingChapter && (
                <div className="mb-6 rounded-2xl border border-[#ffe00055] bg-[#0e1319] p-5 space-y-4 shadow-xl">
                  <h4 className="font-bold text-sm text-[#ffe000]">
                    {editingChapter.id && chaptersList.some((c) => c.id === editingChapter.id) ? 'Edit Chapter' : 'Publish Chapter'}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Manga Series</label>
                      <select
                        value={editingChapter.mangaId || ''}
                        onChange={(e) => {
                          const selected = mangaList.find((m) => m.id === e.target.value);
                          setEditingChapter({
                            ...editingChapter,
                            mangaId: e.target.value,
                            mangaTitle: selected?.title || ''
                          });
                        }}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      >
                        {mangaList.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Chapter Number</label>
                      <input
                        type="number"
                        value={editingChapter.chapterNumber || 1}
                        onChange={(e) => setEditingChapter({ ...editingChapter, chapterNumber: Number(e.target.value) })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Publication Status</label>
                      <select
                        value={editingChapter.status || 'published'}
                        onChange={(e) => setEditingChapter({ ...editingChapter, status: e.target.value as 'published' | 'draft' })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      >
                        <option value="published">Published (Live to Readers)</option>
                        <option value="draft">Draft (Private)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Chapter Title</label>
                    <input
                      type="text"
                      value={editingChapter.title || ''}
                      onChange={(e) => setEditingChapter({ ...editingChapter, title: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="e.g. Chapter 01: Awakening in the Ashes"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Hinglish Story Script &amp; Dialogue</label>
                    <textarea
                      rows={6}
                      value={editingChapter.hinglishText || ''}
                      onChange={(e) => setEditingChapter({ ...editingChapter, hinglishText: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-3 text-xs text-white leading-relaxed"
                      placeholder="Write your Hinglish chapter script here. Double-space between paragraphs..."
                    />
                  </div>

                  {/* Comic Images Upload */}
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">
                      Comic Page Panels ({editingChapter.pages?.length || 0} pages uploaded)
                    </label>

                    {/* Previews of uploaded pages */}
                    {editingChapter.pages && editingChapter.pages.length > 0 && (
                      <div className="mb-3 grid grid-cols-3 sm:grid-cols-6 gap-2 p-2.5 rounded-xl border border-[#2a343e] bg-[#0c1015]">
                        {editingChapter.pages.map((pageUrl, pIdx) => (
                          <div key={pIdx} className="relative group rounded-lg overflow-hidden border border-[#303840] aspect-[2/3] bg-black">
                            <img src={pageUrl} alt={`Page ${pIdx + 1}`} className="w-full h-full object-cover" />
                            <span className="absolute bottom-1 left-1 bg-black/80 text-[8px] font-black px-1 rounded text-[#ffe000]">
                              P.{pIdx + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingChapter((prev) => ({
                                  ...prev,
                                  pages: prev?.pages?.filter((_, idx) => idx !== pIdx) || []
                                }));
                              }}
                              className="absolute top-1 right-1 bg-red-600/90 text-white rounded p-0.5 opacity-0 group-hover:opacity-100 transition"
                              title="Delete Page"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    <label className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-[#3a4550] bg-[#121820] p-4 text-xs font-bold text-gray-300 cursor-pointer hover:border-[#ffe000]">
                      {isUploading ? <Loader2 className="h-4 w-4 animate-spin text-[#ffe000]" /> : <Upload className="h-4 w-4 text-[#ffe000]" />}
                      <span>{isUploading ? (uploadProgressText || 'Uploading pages...') : 'Upload Comic Pages (Images)'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          const files = Array.from(e.target.files || []);
                          if (files.length === 0) return;
                          files.forEach((file) => {
                            handleImageFile(file, (url) => {
                              setEditingChapter((prev) => ({
                                ...prev,
                                pages: [...(prev?.pages || []), url]
                              }));
                            });
                          });
                        }}
                      />
                    </label>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button onClick={() => setEditingChapter(null)} className="rounded-xl border border-[#303840] px-4 py-2 text-xs font-bold text-gray-300">
                      Cancel
                    </button>
                    <button
                      onClick={async () => {
                        if (!editingChapter.title) return alert('Title required');
                        const finalCh: Chapter = {
                          id: editingChapter.id || `ch-${Date.now()}`,
                          mangaId: editingChapter.mangaId || mangaList[0]?.id || '',
                          mangaTitle: editingChapter.mangaTitle || mangaList[0]?.title || '',
                          chapterNumber: editingChapter.chapterNumber || 1,
                          title: editingChapter.title || '',
                          hinglishText: editingChapter.hinglishText || '',
                          pages: editingChapter.pages || [],
                          status: editingChapter.status || 'published',
                          createdAt: editingChapter.createdAt || new Date().toISOString(),
                          updatedAt: new Date().toISOString()
                        };
                        await saveChapter(finalCh);
                        setEditingChapter(null);
                        notify('Chapter published!');
                      }}
                      className="rounded-xl bg-[#ffe000] px-5 py-2 text-xs font-black text-black hover:bg-yellow-300"
                    >
                      Publish Chapter
                    </button>
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-[#222a30] bg-[#0c1015] divide-y divide-[#182028]">
                {chaptersList.map((ch) => (
                  <div key={ch.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded bg-[#ffe00020] px-1.5 py-0.5 text-[9px] font-black text-[#ffe000]">
                          CH. 0{ch.chapterNumber}
                        </span>
                        <strong className="text-sm font-bold text-white">{ch.title}</strong>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                          ch.status === 'published' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {ch.status}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-400 mt-1 block">
                        Series: {ch.mangaTitle} · {ch.pages?.length || 0} comic panels
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingChapter(ch)} className="rounded-lg border border-[#303840] px-3 py-1.5 text-xs text-gray-200 hover:border-[#ffe000]">
                        Edit
                      </button>
                      <button
                        onClick={async () => {
                          if (confirm(`Delete "${ch.title}"?`)) {
                            await deleteChapter(ch.id);
                            notify('Chapter deleted');
                          }
                        }}
                        className="p-1.5 text-gray-500 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: ANIMATIONS */}
          {activeTab === 'animations' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-heading text-xl font-bold uppercase text-white">
                    Animation Spotlight &amp; Project Trailers
                  </h3>
                  <p className="text-xs text-[#8e98a2]">
                    Manage showcase trailers, Sakuga cut spotlights, and YouTube videos.
                  </p>
                </div>
                <button
                  onClick={() =>
                    setEditingAnimation({
                      id: `anim-${Date.now()}`,
                      title: '',
                      subtitle: 'PROJECT SPOTLIGHT',
                      description: '',
                      youtubeUrl: siteSettings.youtubeUrl,
                      thumbnailUrl: '/assets/animation-preview.jpg',
                      duration: 'PREVIEW',
                      featured: true
                    })
                  }
                  className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black hover:bg-yellow-300"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add Project</span>
                </button>
              </div>

              {editingAnimation && (
                <div className="mb-6 rounded-2xl border border-[#ffe00055] bg-[#0e1319] p-5 space-y-4 shadow-xl">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Project Title</label>
                      <input
                        type="text"
                        value={editingAnimation.title || ''}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, title: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">YouTube Video Link</label>
                      <input
                        type="text"
                        value={editingAnimation.youtubeUrl || ''}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, youtubeUrl: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Category / Project Type</label>
                      <input
                        type="text"
                        value={editingAnimation.category || 'Fan-Made Anime Episode'}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, category: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="e.g. Episode, Trailer, Spotlight, Cut"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Episode Number (optional)</label>
                      <input
                        type="number"
                        value={editingAnimation.episodeNumber || 1}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, episodeNumber: Number(e.target.value) })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="1"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Publication Date</label>
                      <input
                        type="date"
                        value={editingAnimation.releaseDate || new Date().toISOString().split('T')[0]}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, releaseDate: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Description &amp; Episode Synopsis</label>
                    <textarea
                      rows={2}
                      value={editingAnimation.description || ''}
                      onChange={(e) => setEditingAnimation({ ...editingAnimation, description: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Episode plot and storyline summary..."
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Thumbnail Artwork</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value={editingAnimation.thumbnailUrl || ''}
                        onChange={(e) => setEditingAnimation({ ...editingAnimation, thumbnailUrl: e.target.value })}
                        className="flex-1 rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="/assets/animation-preview.jpg or image URL"
                      />
                      <label className="flex items-center gap-1 rounded-lg border border-[#303840] bg-[#161d26] px-3.5 py-2 text-xs font-bold cursor-pointer hover:border-[#ffe000] text-gray-200">
                        {isUploading ? <Loader2 className="h-3.5 w-3.5 animate-spin text-[#ffe000]" /> : <Upload className="h-3.5 w-3.5 text-[#ffe000]" />}
                        <span>Upload File</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageFile(file, (url) => setEditingAnimation({ ...editingAnimation, thumbnailUrl: url }));
                          }}
                        />
                      </label>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-3">
                    <button onClick={() => setEditingAnimation(null)} className="rounded-xl border border-[#303840] px-4 py-2 text-xs font-bold text-gray-300">
                      Cancel
                    </button>
                    <button
                      onClick={async () => {
                        if (!editingAnimation.title) return alert('Title required');
                        const finalAnim: AnimationProject = {
                          id: editingAnimation.id || `anim-${Date.now()}`,
                          title: editingAnimation.title || '',
                          subtitle: editingAnimation.subtitle || 'PROJECT SPOTLIGHT',
                          description: editingAnimation.description || '',
                          youtubeUrl: editingAnimation.youtubeUrl || '',
                          thumbnailUrl: editingAnimation.thumbnailUrl || '/assets/animation-preview.jpg',
                          duration: editingAnimation.duration || 'PREVIEW',
                          featured: editingAnimation.featured ?? true,
                          category: editingAnimation.category || 'Fan-Made Anime Episode',
                          episodeNumber: editingAnimation.episodeNumber || 1,
                          releaseDate: editingAnimation.releaseDate || new Date().toISOString().split('T')[0],
                          createdAt: editingAnimation.createdAt || new Date().toISOString()
                        };
                        await saveAnimation(finalAnim);
                        setEditingAnimation(null);
                        notify('Animation episode saved to Firestore!');
                      }}
                      className="rounded-xl bg-[#ffe000] px-5 py-2 text-xs font-black text-black hover:bg-yellow-300"
                    >
                      Save Animation
                    </button>
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-[#222a30] bg-[#0c1015] divide-y divide-[#182028]">
                {animationsList.map((a) => (
                  <div key={a.id} className="p-4 flex items-center justify-between gap-4">
                    <div>
                      <strong className="text-sm font-bold text-white">{a.title}</strong>
                      <span className="block text-[10px] text-gray-400">{a.youtubeUrl}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingAnimation(a)} className="rounded-lg border border-[#303840] px-3 py-1.5 text-xs text-gray-200 hover:border-[#ffe000]">
                        Edit
                      </button>
                      <button onClick={() => deleteAnimation(a.id)} className="p-1.5 text-gray-500 hover:text-red-400">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: EDITS & SHORTS */}
          {activeTab === 'edits' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-heading text-xl font-bold uppercase text-white">
                    Anime Edits &amp; Shorts Management
                  </h3>
                  <p className="text-xs text-[#8e98a2]">
                    Publish YouTube Shorts and Instagram Reels to your edits catalog.
                  </p>
                </div>
                <button
                  onClick={() =>
                    setEditingEdit({
                      id: `edit-${Date.now()}`,
                      title: '',
                      category: 'Anime Edit · Shorts',
                      platform: 'youtube',
                      videoUrl: siteSettings.youtubeUrl,
                      thumbnailUrl: '/assets/manga-crimson.jpg',
                      duration: '0:30',
                      order: editsList.length + 1
                    })
                  }
                  className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black hover:bg-yellow-300"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>New Edit</span>
                </button>
              </div>

              {editingEdit && (
                <div className="mb-6 rounded-2xl border border-[#ffe00055] bg-[#0e1319] p-5 space-y-4 shadow-xl">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Title</label>
                      <input
                        type="text"
                        value={editingEdit.title || ''}
                        onChange={(e) => setEditingEdit({ ...editingEdit, title: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Platform</label>
                      <select
                        value={editingEdit.platform || 'youtube'}
                        onChange={(e) => setEditingEdit({ ...editingEdit, platform: e.target.value as 'youtube' | 'instagram' })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                      >
                        <option value="youtube">YouTube</option>
                        <option value="instagram">Instagram</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Video / Shorts URL</label>
                    <input
                      type="text"
                      value={editingEdit.videoUrl || ''}
                      onChange={(e) => setEditingEdit({ ...editingEdit, videoUrl: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3">
                    <button onClick={() => setEditingEdit(null)} className="rounded-xl border border-[#303840] px-4 py-2 text-xs font-bold text-gray-300">
                      Cancel
                    </button>
                    <button
                      onClick={async () => {
                        if (!editingEdit.title) return alert('Title required');
                        const finalEdit: AnimeEdit = {
                          id: editingEdit.id || `edit-${Date.now()}`,
                          title: editingEdit.title || '',
                          category: editingEdit.category || 'Anime Edit · Shorts',
                          platform: editingEdit.platform || 'youtube',
                          videoUrl: editingEdit.videoUrl || siteSettings.youtubeUrl,
                          thumbnailUrl: editingEdit.thumbnailUrl || '/assets/manga-crimson.jpg',
                          duration: editingEdit.duration || '0:30',
                          order: editingEdit.order || 1
                        };
                        await saveEdit(finalEdit);
                        setEditingEdit(null);
                        notify('Edit saved!');
                      }}
                      className="rounded-xl bg-[#ffe000] px-5 py-2 text-xs font-black text-black hover:bg-yellow-300"
                    >
                      Save Edit
                    </button>
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-[#222a30] bg-[#0c1015] divide-y divide-[#182028]">
                {editsList.map((e) => (
                  <div key={e.id} className="p-4 flex items-center justify-between gap-4">
                    <div>
                      <strong className="text-sm font-bold text-white">{e.title}</strong>
                      <span className="block text-[10px] text-gray-400">{e.category} · {e.duration} · {e.platform}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingEdit(e)} className="rounded-lg border border-[#303840] px-3 py-1.5 text-xs text-gray-200 hover:border-[#ffe000]">
                        Edit
                      </button>
                      <button onClick={() => deleteEdit(e.id)} className="p-1.5 text-gray-500 hover:text-red-400">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: NEWS & COMMUNITY POSTS */}
          {activeTab === 'news' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-heading text-xl font-bold uppercase text-white">
                    News &amp; Community Updates Posts
                  </h3>
                  <p className="text-xs text-[#8e98a2]">
                    Publish updates that appear live on the homepage "Latest Updates" feed.
                  </p>
                </div>
                <button
                  onClick={() =>
                    setEditingNews({
                      id: `news-${Date.now()}`,
                      title: '',
                      category: 'New Manga Chapter',
                      content: '',
                      linkUrl: '#manga',
                      imageUrl: '/assets/manga-shadow-sun.jpg',
                      createdAt: new Date().toISOString()
                    })
                  }
                  className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black hover:bg-yellow-300"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Create News Post</span>
                </button>
              </div>

              {editingNews && (
                <div className="mb-6 rounded-2xl border border-[#ffe00055] bg-[#0e1319] p-5 space-y-4 shadow-xl">
                  <h4 className="font-bold text-sm text-[#ffe000]">Create / Edit News Post</h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Post Headline</label>
                      <input
                        type="text"
                        value={editingNews.title || ''}
                        onChange={(e) => setEditingNews({ ...editingNews, title: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                        placeholder="e.g. The Crimson Breathing Ch 04 Releasing Soon"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Category Label</label>
                      <input
                        type="text"
                        value={editingNews.category || ''}
                        onChange={(e) => setEditingNews({ ...editingNews, category: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                        placeholder="e.g. New Manga Chapter, New Animation, Announcement"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Post Details &amp; Content</label>
                    <textarea
                      rows={3}
                      value={editingNews.content || ''}
                      onChange={(e) => setEditingNews({ ...editingNews, content: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Write the announcement or update description..."
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Link Destination (optional)</label>
                      <input
                        type="text"
                        value={editingNews.linkUrl || ''}
                        onChange={(e) => setEditingNews({ ...editingNews, linkUrl: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="#manga or https://youtube.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase mb-1">Thumbnail Artwork (optional)</label>
                      <input
                        type="text"
                        value={editingNews.imageUrl || ''}
                        onChange={(e) => setEditingNews({ ...editingNews, imageUrl: e.target.value })}
                        className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2 text-xs text-white"
                        placeholder="/assets/manga-crimson.jpg"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button onClick={() => setEditingNews(null)} className="rounded-xl border border-[#303840] px-4 py-2 text-xs font-bold text-gray-300">
                      Cancel
                    </button>
                    <button
                      onClick={async () => {
                        if (!editingNews.title) return alert('Headline required');
                        const finalNews: NewsPost = {
                          id: editingNews.id || `news-${Date.now()}`,
                          title: editingNews.title || '',
                          category: editingNews.category || 'Announcement',
                          content: editingNews.content || '',
                          linkUrl: editingNews.linkUrl || '#manga',
                          imageUrl: editingNews.imageUrl || '/assets/manga-shadow-sun.jpg',
                          createdAt: editingNews.createdAt || new Date().toISOString()
                        };
                        await saveNewsPost(finalNews);
                        setEditingNews(null);
                        notify('News post published live!');
                      }}
                      className="rounded-xl bg-[#ffe000] px-5 py-2 text-xs font-black text-black hover:bg-yellow-300"
                    >
                      Publish News Post
                    </button>
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-[#222a30] bg-[#0c1015] divide-y divide-[#182028]">
                {newsList.map((n) => (
                  <div key={n.id} className="p-4 flex items-center justify-between gap-4">
                    <div>
                      <span className="text-[9px] font-black uppercase text-[#ffe000]">{n.category}</span>
                      <strong className="block text-sm font-bold text-white">{n.title}</strong>
                      <p className="text-xs text-gray-400 line-clamp-1 mt-0.5">{n.content}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingNews(n)} className="rounded-lg border border-[#303840] px-3 py-1.5 text-xs text-gray-200 hover:border-[#ffe000]">
                        Edit
                      </button>
                      <button onClick={() => deleteNewsPost(n.id)} className="p-1.5 text-gray-500 hover:text-red-400">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: HOLE SETUP & SOCIALS */}
          {activeTab === 'settings' && (
            <div className="max-w-3xl space-y-5">
              <div>
                <h3 className="font-heading text-xl font-bold uppercase text-white">
                  Hole Website Setup &amp; Social Links
                </h3>
                <p className="text-xs text-[#8e98a2]">
                  Configure your official brand identity, Hero banners, contact email, and channel credentials.
                </p>
              </div>

              {/* Brand and Website Identity */}
              <div className="rounded-2xl border border-[#ffe00030] bg-[#0f141b] p-5 space-y-4">
                <h4 className="font-bold text-xs uppercase text-[#ffe000]">Brand &amp; Website Identity</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Website Name</label>
                    <input
                      type="text"
                      value={settingsForm.siteTitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, siteTitle: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="AWSK ANIMEX"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Brand Identity Subtext</label>
                    <input
                      type="text"
                      value={settingsForm.brandSubtext || 'Powered by AWSK_EDITZ'}
                      onChange={(e) => setSettingsForm({ ...settingsForm, brandSubtext: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Powered by AWSK_EDITZ"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Official Tagline</label>
                    <input
                      type="text"
                      value={settingsForm.heroTitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heroTitle: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Beyond Anime. Beyond Imagination."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Hinglish Tagline</label>
                    <input
                      type="text"
                      value={settingsForm.hinglishTagline || 'Har Kahani Mein Ek Nayi Duniya.'}
                      onChange={(e) => setSettingsForm({ ...settingsForm, hinglishTagline: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                      placeholder="Har Kahani Mein Ek Nayi Duniya."
                    />
                  </div>
                </div>
              </div>

              {/* Hero Banner Image */}
              <div className="rounded-2xl border border-[#263039] bg-[#0f141b] p-5 space-y-3">
                <label className="block text-[10px] font-black uppercase tracking-widest text-[#ffe000]">
                  Hero Banner Graphic Artwork
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={settingsForm.heroBannerUrl || ''}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroBannerUrl: e.target.value })}
                    className="flex-1 rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                    placeholder="/assets/hero-banner.png or custom image URL"
                  />
                  <label className="flex items-center gap-1.5 rounded-lg border border-[#303840] bg-[#161d26] px-3.5 py-2.5 text-xs font-bold cursor-pointer hover:border-[#ffe000] text-gray-200">
                    {isUploading ? <Loader2 className="h-3.5 w-3.5 animate-spin text-[#ffe000]" /> : <Upload className="h-3.5 w-3.5 text-[#ffe000]" />}
                    <span>Upload Banner</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleImageFile(file, (url) => setSettingsForm({ ...settingsForm, heroBannerUrl: url }));
                      }}
                    />
                  </label>
                </div>
                {settingsForm.heroBannerUrl && (
                  <div className="mt-2 rounded-lg overflow-hidden border border-[#303840] max-h-24">
                    <img src={settingsForm.heroBannerUrl} alt="Banner Preview" className="w-full h-24 object-cover" />
                  </div>
                )}
              </div>

              {/* Headings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-gray-400 uppercase mb-1">Subscriber Badge Count</label>
                  <input
                    type="text"
                    value={settingsForm.subscribersCount || '4,230+ and growing'}
                    onChange={(e) => setSettingsForm({ ...settingsForm, subscribersCount: e.target.value })}
                    className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                    placeholder="4,230+ and growing"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-400 uppercase mb-1">Lead Channel Editor Name</label>
                  <input
                    type="text"
                    value={settingsForm.editorName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, editorName: e.target.value })}
                    className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-gray-400 uppercase mb-1">Hero Subtitle</label>
                <textarea
                  rows={2}
                  value={settingsForm.heroSubtitle}
                  onChange={(e) => setSettingsForm({ ...settingsForm, heroSubtitle: e.target.value })}
                  className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                />
              </div>

              {/* Social links */}
              <div className="rounded-2xl border border-[#263039] bg-[#0f141b] p-5 space-y-4">
                <h4 className="font-bold text-xs uppercase text-[#ffe000]">Official Channel Connections</h4>
                
                <div>
                  <label className="block text-[10px] text-gray-400 uppercase mb-1">Official YouTube Channel Link</label>
                  <input
                    type="text"
                    value={settingsForm.youtubeUrl}
                    onChange={(e) => setSettingsForm({ ...settingsForm, youtubeUrl: e.target.value })}
                    className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-gray-400 uppercase mb-1">Official Instagram Link</label>
                  <input
                    type="text"
                    value={settingsForm.instagramUrl}
                    onChange={(e) => setSettingsForm({ ...settingsForm, instagramUrl: e.target.value })}
                    className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Business Contact Email</label>
                    <input
                      type="email"
                      value={settingsForm.contactEmail}
                      onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-gray-400 uppercase mb-1">Lead Channel Editor Name</label>
                    <input
                      type="text"
                      value={settingsForm.editorName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, editorName: e.target.value })}
                      className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-gray-400 uppercase mb-1">Global Top Announcement Notice</label>
                <input
                  type="text"
                  value={settingsForm.announcement || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, announcement: e.target.value })}
                  className="w-full rounded-lg border border-[#303840] bg-[#121820] p-2.5 text-xs text-white"
                />
              </div>

              <button
                onClick={async () => {
                  await saveSiteSettings({ ...settingsForm, updatedAt: new Date().toISOString() });
                  notify('Hole website setup saved to Firestore!');
                }}
                className="rounded-xl bg-[#ffe000] px-6 py-3 text-xs font-black text-black hover:bg-yellow-300 shadow-lg"
              >
                Save Hole Setup &amp; Links
              </button>
            </div>
          )}

          {/* TAB: IMAGE STUDIO */}
          {activeTab === 'images' && (
            <div className="max-w-2xl space-y-4">
              <div>
                <h3 className="font-heading text-xl font-bold uppercase text-white">
                  Image Upload Studio
                </h3>
                <p className="text-xs text-[#8e98a2]">
                  Select any high-res anime artwork, manga panel, or banner. The studio instantly optimizes it for direct usage in manga covers, news posts, or banners.
                </p>
              </div>

              <label className="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-[#3a4550] bg-[#11161d] p-8 text-center cursor-pointer hover:border-[#ffe000] transition">
                {isUploading ? <Loader2 className="h-8 w-8 text-[#ffe000] animate-spin" /> : <Upload className="h-8 w-8 text-[#ffe000]" />}
                <span className="text-xs font-bold text-white">
                  {isUploading ? (uploadProgressText || 'Uploading image...') : 'Click or drag image file here to process'}
                </span>
                <span className="text-[10px] text-[#737e87]">Supports PNG, JPG, WebP, SVG (Max 15MB)</span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageFile(file, (url) => setUploadedImageUrl(url));
                  }}
                />
              </label>

              {uploadedImageUrl && (
                <div className="rounded-xl border border-[#2a343e] bg-[#0d1217] p-4 space-y-3">
                  <span className="text-[10px] font-bold text-[#ffe000] uppercase">Processed Image Preview</span>
                  <img src={uploadedImageUrl} alt="Uploaded" className="h-44 w-auto rounded-lg object-contain bg-black/40 mx-auto" />
                  
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={uploadedImageUrl.slice(0, 100) + '...'}
                      className="flex-1 rounded-lg border border-[#303840] bg-[#121820] p-2 text-[10px] text-gray-300"
                    />
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(uploadedImageUrl);
                        notify('Full image data copied to clipboard!');
                      }}
                      className="rounded-lg bg-[#ffe000] px-3 py-2 text-xs font-black text-black"
                    >
                      Copy Image
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: DATABASE SEED */}
          {activeTab === 'seed' && (
            <div className="max-w-xl space-y-4">
              <h3 className="font-heading text-xl font-bold uppercase text-white flex items-center gap-2">
                <Database className="h-5 w-5 text-[#ffe000]" />
                Initialize / Reset Firestore Database
              </h3>
              <p className="text-xs text-[#aeb5bb] leading-relaxed">
                Clicking the button below syncs all canonical AWSK_EDITZ records into your live Firestore database:
                mangas (*Shadows of the Last Sun*, *The Crimson Breathing*, *Reborn as a Warrior*, *The Forgotten Clan*),
                Hinglish chapters, animation trailers, video edits, and official social credentials.
              </p>

              <div className="rounded-xl border border-[#263039] bg-[#0f141a] p-4 text-xs text-gray-300">
                <span className="block font-bold text-[#ffe000] mb-1">Connected Project: the-physics-dxqhd</span>
                <span>Database: ai-studio-3fd6672c-18fb-4b86-b960-7a028a5bb4da</span>
              </div>

              <button
                onClick={async () => {
                  try {
                    await seedInitialDataToFirestore();
                    notify('Firestore populated successfully!');
                  } catch (err: unknown) {
                    notify('Seed error: ' + (err instanceof Error ? err.message : String(err)), 'error');
                  }
                }}
                className="flex items-center gap-2 rounded-xl bg-[#ffe000] px-6 py-3 text-xs font-black text-black hover:bg-yellow-300 transition shadow-lg"
              >
                <Sparkles className="h-4 w-4" />
                <span>Seed Initial Anime Universe Data to Firestore</span>
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
