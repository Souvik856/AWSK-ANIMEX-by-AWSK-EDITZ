import React from 'react';
import { ArrowUpRight } from 'lucide-react';

export const UniverseSection: React.FC = () => {
  return (
    <section id="universe" className="mx-auto max-w-7xl px-4 md:px-8 pt-16">
      <div className="flex items-end justify-between border-b border-[#20272e] pb-3 mb-6">
        <div>
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
            BUILD A WORLD OF YOUR OWN
          </div>
          <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
            Anime <span className="text-[#ffe000]">Universe</span>
          </h2>
        </div>
        <span className="text-xs text-[#737e87]">Fan-made &amp; original worlds</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Original Universe */}
        <article className="grid grid-cols-1 sm:grid-cols-12 min-h-[190px] overflow-hidden rounded-2xl border border-[#263039] bg-[#0d1115] transition duration-300 hover:border-[#ffe00055]">
          <div className="sm:col-span-5 flex items-center justify-center font-heading text-6xl md:text-7xl font-black text-[#ffe000aa] bg-gradient-to-br from-[#1c1b16] to-[#08090b] border-b sm:border-b-0 sm:border-r border-[#263039] p-6">
            創造
          </div>
          <div className="sm:col-span-7 p-6 flex flex-col justify-between">
            <div>
              <span className="rounded bg-[#0b0d0bb0] border border-[#ffe0005c] px-2 py-0.5 text-[8px] font-black text-[#ffe000] tracking-widest uppercase">
                ORIGINAL
              </span>
              <h3 className="font-heading mt-2 text-2xl font-black uppercase text-white">
                Original Universe
              </h3>
              <p className="mt-1 text-xs text-[#aeb5bb] leading-relaxed">
                Notun world. Notun character. Notun legend. Sob golpo ekhanei shuru with exclusive characters and Hinglish stories.
              </p>
            </div>
            <a
              href="#manga"
              className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-[#ffe000] hover:underline"
            >
              <span>Explore stories</span>
              <ArrowUpRight className="h-3 w-3" />
            </a>
          </div>
        </article>

        {/* Alternate Stories */}
        <article className="grid grid-cols-1 sm:grid-cols-12 min-h-[190px] overflow-hidden rounded-2xl border border-[#263039] bg-[#0d1115] transition duration-300 hover:border-[#ff3b3155]">
          <div className="sm:col-span-5 flex items-center justify-center font-heading text-5xl md:text-6xl font-black text-[#ff6158] bg-gradient-to-br from-[#1c1112] to-[#08090b] border-b sm:border-b-0 sm:border-r border-[#263039] p-6">
            IF?
          </div>
          <div className="sm:col-span-7 p-6 flex flex-col justify-between">
            <div>
              <span className="rounded bg-[#ff3b3120] border border-[#ff3b315c] px-2 py-0.5 text-[8px] font-black text-[#ff7069] tracking-widest uppercase">
                FAN-MADE
              </span>
              <h3 className="font-heading mt-2 text-2xl font-black uppercase text-white">
                Alternate Stories
              </h3>
              <p className="mt-1 text-xs text-[#aeb5bb] leading-relaxed">
                What-if ideas and fan theories—clearly labelled, made with heart by passionate anime fans and creators.
              </p>
            </div>
            <a
              href="#community"
              className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-[#ff7069] hover:underline"
            >
              <span>Explore ideas</span>
              <ArrowUpRight className="h-3 w-3" />
            </a>
          </div>
        </article>
      </div>
    </section>
  );
};
