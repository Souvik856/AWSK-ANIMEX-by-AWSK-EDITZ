import React from 'react';
import { useData } from '../context/DataContext';
import { Youtube, Instagram, Crown, ArrowUpRight } from 'lucide-react';

export const CommunitySection: React.FC = () => {
  const { siteSettings } = useData();

  return (
    <section id="community" className="mx-auto max-w-7xl px-4 md:px-8 pt-16">
      <div className="relative overflow-hidden rounded-2xl border border-[#2a2c20] bg-gradient-to-r from-[#0b0e10] via-[#121614] to-[#0a0c0e] p-8 md:p-12 shadow-2xl">
        {/* Glow bubble */}
        <div className="absolute top-0 right-0 h-64 w-64 bg-[#ffe00010] blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8">
            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
              YOUR FANDOM. YOUR UNIVERSE.
            </div>
            <h2 className="font-heading mt-2 text-4xl sm:text-5xl font-black uppercase text-white leading-tight">
              Join the <span className="text-[#ffe000]">Community</span>
            </h2>
            <p className="mt-3 max-w-xl text-xs sm:text-sm text-[#aeb5bb] leading-relaxed">
              New Hinglish chapters, edit drops, animation trailers, fan theories and project updates—all in one place with 4,230+ anime enthusiasts.
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a
                href={siteSettings.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-xl bg-[#ffe000] px-5 py-3 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95 shadow-lg shadow-yellow-500/10"
              >
                <Youtube className="h-4 w-4" />
                <span>Follow on YouTube (4,230+)</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>

              <a
                href={siteSettings.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-xl border border-[#48515a] bg-[#090c0dbd] px-5 py-3 text-xs font-bold text-white hover:border-[#ffe000] hover:text-[#ffe000] transition active:scale-95"
              >
                <Instagram className="h-4 w-4 text-pink-400" />
                <span>Follow on Instagram</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          {/* Stat badge right */}
          <div className="lg:col-span-4 rounded-xl border border-[#30362c] bg-[#0f131180] p-6 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <Crown className="h-8 w-8 text-[#ffe000]" />
              <span className="rounded bg-red-500/20 border border-red-500/40 px-2 py-0.5 text-[9px] font-bold text-red-400">
                GROWING DAILY
              </span>
            </div>
            <strong className="font-heading text-2xl font-black text-white mt-1">
              ONE UNIVERSE
            </strong>
            <span className="text-xs text-[#a2abb2]">
              Stories without limits.
            </span>
            <div className="my-2 h-[2px] w-16 bg-[#ffe000]" />
            <span className="text-[10px] text-[#78848f]">
              Lead Channel Editor: <strong className="text-white">{siteSettings.editorName || "Souvik Deb"}</strong>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
