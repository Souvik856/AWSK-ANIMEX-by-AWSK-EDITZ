import React from 'react';
import { useData } from '../context/DataContext';
import { Manga } from '../types';
import { X, Bookmark, BookOpen, Trash2, ArrowUpRight } from 'lucide-react';

interface BookmarksModalProps {
  onClose: () => void;
  onSelectManga: (manga: Manga) => void;
}

export const BookmarksModal: React.FC<BookmarksModalProps> = ({ onClose, onSelectManga }) => {
  const { bookmarks, mangaList, toggleBookmark, readingHistory } = useData();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative flex flex-col max-h-[85vh] w-full max-w-xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0c1015] shadow-2xl z-10">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] px-6 py-4 bg-[#0f141b]">
          <div className="flex items-center gap-2">
            <Bookmark className="h-4 w-4 text-[#ffe000] fill-current" />
            <h3 className="font-heading text-xl font-bold uppercase text-white">
              My Bookmarks &amp; Reading History
            </h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#303840] text-gray-300 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-widest text-[#ffe000] mb-3">
              SAVED BOOKMARKS ({bookmarks.length})
            </h4>

            {bookmarks.length === 0 ? (
              <p className="rounded-xl border border-[#1f2730] bg-[#080b0e] p-6 text-center text-xs text-[#78848f]">
                No bookmarks saved yet. Click the bookmark button while reading any manga to save it!
              </p>
            ) : (
              <div className="divide-y divide-[#1c2228] rounded-xl border border-[#222a30] bg-[#090c0f] overflow-hidden">
                {bookmarks.map((b) => {
                  const manga = mangaList.find((m) => m.id === b.mangaId);
                  return (
                    <div
                      key={b.id}
                      className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition"
                    >
                      <div
                        onClick={() => {
                          if (manga) {
                            onSelectManga(manga);
                            onClose();
                          }
                        }}
                        className="cursor-pointer flex items-center gap-3"
                      >
                        {b.coverUrl && (
                          <img
                            src={b.coverUrl}
                            alt={b.mangaTitle}
                            className="h-10 w-8 object-cover rounded"
                          />
                        )}
                        <div>
                          <strong className="block text-xs font-bold text-white hover:text-[#ffe000] transition">
                            {b.mangaTitle}
                          </strong>
                          <span className="text-[10px] text-[#8e98a2]">
                            Last chapter: Ch. 0{b.lastReadChapter || 1}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {manga && (
                          <button
                            onClick={() => {
                              onSelectManga(manga);
                              onClose();
                            }}
                            className="flex items-center gap-1 rounded bg-[#ffe000] px-2.5 py-1 text-[10px] font-black text-black hover:bg-yellow-300"
                          >
                            <span>Read</span>
                            <ArrowUpRight className="h-3 w-3" />
                          </button>
                        )}
                        <button
                          onClick={() => manga && toggleBookmark(manga)}
                          className="p-1.5 text-gray-500 hover:text-red-400 transition"
                          title="Remove bookmark"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Reading history */}
          {readingHistory.length > 0 && (
            <div className="pt-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-[#8e98a2] mb-3">
                RECENTLY VIEWED
              </h4>
              <div className="rounded-xl border border-[#1f2730] bg-[#080b0e] p-3 text-xs divide-y divide-[#171e25]">
                {readingHistory.slice(0, 5).map((h, idx) => {
                  const m = mangaList.find((item) => item.id === h.mangaId);
                  return (
                    <div key={idx} className="py-2 flex items-center justify-between">
                      <span className="font-semibold text-white">{m?.title || h.mangaId}</span>
                      <span className="text-[10px] text-[#ffe000]">Ch. 0{h.chapterNumber}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
