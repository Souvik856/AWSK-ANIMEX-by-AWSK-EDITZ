import React from 'react';
import { X, Youtube, ExternalLink } from 'lucide-react';

interface VideoModalProps {
  title: string;
  videoUrl: string;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ title, videoUrl, onClose }) => {
  // Extract YouTube video ID if possible
  const getEmbedUrl = (url: string) => {
    try {
      const parsed = new URL(url);
      if (parsed.hostname.includes('youtube.com')) {
        const v = parsed.searchParams.get('v');
        if (v) return `https://www.youtube.com/embed/${v}?autoplay=1`;
      }
      if (parsed.hostname.includes('youtu.be')) {
        const id = parsed.pathname.slice(1);
        if (id) return `https://www.youtube.com/embed/${id}?autoplay=1`;
      }
    } catch {
      // Fallback
    }
    return null;
  };

  const embedUrl = getEmbedUrl(videoUrl);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative flex flex-col w-full max-w-4xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0c1015] shadow-2xl z-10">
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] px-5 py-3.5 bg-[#0f141b]">
          <div className="flex items-center gap-2 truncate pr-4">
            <Youtube className="h-4 w-4 text-red-500 shrink-0" />
            <h3 className="font-heading text-lg font-bold uppercase text-white truncate">
              {title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#303840] text-gray-300 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="relative aspect-video w-full bg-black">
          {embedUrl ? (
            <iframe
              src={embedUrl}
              title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="h-full w-full border-0"
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center text-white">
              <Youtube className="h-16 w-16 text-red-500 mb-3" />
              <h4 className="font-heading text-2xl font-black">{title}</h4>
              <p className="mt-2 text-xs text-gray-400 max-w-md">
                This project video is hosted on our official channel. Click below to watch the full project!
              </p>
              <a
                href={videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 flex items-center gap-2 rounded-xl bg-[#ffe000] px-5 py-2.5 text-xs font-black text-black hover:bg-yellow-300"
              >
                <span>Watch on Channel</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
