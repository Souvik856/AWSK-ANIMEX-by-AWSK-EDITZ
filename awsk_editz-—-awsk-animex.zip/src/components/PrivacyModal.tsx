import React from 'react';
import { X, ShieldCheck } from 'lucide-react';
import { useData } from '../context/DataContext';

export const PrivacyModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { siteSettings } = useData();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative flex flex-col max-h-[85vh] w-full max-w-2xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0c1015] shadow-2xl z-10">
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] px-6 py-4 bg-[#0f141b]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-[#ffe000]" />
            <h3 className="font-heading text-xl font-bold uppercase text-white">
              Privacy Policy &amp; DMCA Guidelines
            </h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#303840] text-gray-300 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-[#b8c0c8] leading-relaxed">
          <h4 className="font-bold text-sm text-white">1. Community &amp; Content Disclaimer</h4>
          <p>
            AWSK_EDITZ is a creative publication platform celebrating anime fandom, original Hinglish web stories, fan-made animation tributes, and edits. All fan animations and parody edits are clearly labelled and respect original creators.
          </p>

          <h4 className="font-bold text-sm text-white">2. Copyright &amp; DMCA Inquiries</h4>
          <p>
            If you are a copyright owner or an agent thereof and believe that any content hosted on AWSK_EDITZ infringes upon your copyrights, please submit a formal notice to our designated editorial email at <strong className="text-[#ffe000]">{siteSettings.contactEmail}</strong>. We will review and act swiftly.
          </p>

          <h4 className="font-bold text-sm text-white">3. User Data &amp; PWA Privacy</h4>
          <p>
            We do not collect unnecessary personal identifiable information. Account sign-in via Google is solely utilized for authenticated administrative publishing and bookmark synchronization. Your reading history and local preferences are stored safely on your device.
          </p>

          <h4 className="font-bold text-sm text-white">4. Editorial Contact</h4>
          <p>
            Channel Editor: <strong>{siteSettings.editorName || "Souvik Deb"}</strong><br />
            Business Email: <strong>{siteSettings.contactEmail}</strong>
          </p>
        </div>
      </div>
    </div>
  );
};
