import React from 'react';
import { useData } from '../context/DataContext';
import { Youtube, Instagram, Mail, Play, ArrowUpRight, Flame } from 'lucide-react';

interface HeroProps {
  onExploreManga: () => void;
  onWatchProjects: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreManga, onWatchProjects }) => {
  const { siteSettings } = useData();

  return (
    <section className="relative overflow-hidden border-b border-[#222830] bg-[#07090b]">
      {/* Hero Banner Graphic */}
      <div className="relative h-[340px] sm:h-[400px] md:h-[460px] w-full overflow-hidden">
        <img
          src={siteSettings.heroBannerUrl || "/assets/hero-banner.png"}
          alt="Original anime-inspired AWSK_EDITZ cinematic banner"
          className="absolute inset-0 h-full w-full object-cover object-[center_35%] opacity-90 transition duration-700 hover:scale-105"
        />

        {/* Ambient Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#050607f5] via-[#050607cc] to-[#05060740]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07090b] via-transparent to-transparent" />

        {/* Hero Copy Content */}
        <div className="absolute inset-0 mx-auto flex max-w-7xl flex-col justify-center px-6 md:px-12">
          <div className="max-w-2xl">
            {/* Eyebrow */}
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="h-2 w-2 rounded-full bg-[#ffe000] shadow-[0_0_12px_#ffe000] animate-pulse" />
              <span className="text-[10px] md:text-xs font-black tracking-[0.2em] text-[#ffe000] uppercase">
                {siteSettings.brandSubtext || "POWERED BY AWSK_EDITZ"}
              </span>
              <span className="rounded bg-[#ff3b3126] px-2 py-0.5 text-[9px] font-bold text-[#ff6a61] border border-[#ff3b3140]">
                {siteSettings.subscribersCount || "4,230+ SUBSCRIBERS"}
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-heading mt-3 text-4xl sm:text-6xl md:text-7xl font-black leading-[0.9] tracking-tight text-white uppercase">
              BEYOND ANIME.<br />
              <em className="font-normal italic text-[#ffe000] drop-shadow-[0_4px_24px_rgba(255,224,0,0.3)]">
                BEYOND IMAGINATION.
              </em>
            </h1>

            {/* Hinglish Tagline Callout */}
            <div className="mt-3 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#ffe00018] to-transparent border-l-2 border-[#ffe000] py-1 px-3">
              <span className="font-heading text-sm md:text-base font-bold italic tracking-wide text-[#ffe000]">
                “{siteSettings.hinglishTagline || "Har Kahani Mein Ek Nayi Duniya."}”
              </span>
            </div>

            {/* Description */}
            <p className="mt-3 max-w-xl text-xs sm:text-sm md:text-base leading-relaxed text-[#c2c6ca]">
              {siteSettings.heroSubtitle ||
                "Hinglish manga, original worlds, fan-made animations and edits made for anime fans."}
            </p>

            {/* Action Buttons */}
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                onClick={onExploreManga}
                className="group flex items-center gap-2 rounded-xl bg-[#ffe000] px-5 py-3 text-xs md:text-sm font-black text-black shadow-lg shadow-[#ffe00025] hover:bg-[#fff266] transition active:scale-95"
              >
                <span>Explore Manga</span>
                <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>

              <button
                onClick={onWatchProjects}
                className="flex items-center gap-2 rounded-xl border border-[#48515a] bg-[#090c0dbd] px-5 py-3 text-xs md:text-sm font-black text-white hover:border-[#ffe000] hover:text-[#ffe000] transition active:scale-95 backdrop-blur-sm"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Watch Projects</span>
              </button>

              {/* Social Quick Icons */}
              <div className="ml-auto hidden md:flex items-center gap-2">
                <a
                  href={siteSettings.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#303840] bg-[#0a0d12cc] text-red-500 hover:border-red-500 hover:scale-110 transition"
                  title="Official YouTube Channel"
                >
                  <Youtube className="h-5 w-5" />
                </a>
                <a
                  href={siteSettings.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#303840] bg-[#0a0d12cc] text-pink-400 hover:border-pink-400 hover:scale-110 transition"
                  title="Official Instagram Profile"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href={`mailto:${siteSettings.contactEmail}`}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#303840] bg-[#0a0d12cc] text-[#ffe000] hover:border-[#ffe000] hover:scale-110 transition"
                  title="Official Business Email"
                >
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Hero bottom metadata bar */}
        <div className="absolute bottom-3 left-6 right-6 mx-auto flex max-w-7xl items-center justify-between text-[9px] md:text-[10px] tracking-wider text-[#8f979f] uppercase">
          <span>01 / STORIES THAT HIT DIFFERENT</span>
          <div className="mx-4 hidden sm:block h-[1px] flex-1 bg-[#68717a33]" />
          <span>CREATED FOR THE FANDOM · EDITED BY {siteSettings.editorName || "SOUVIK DEB"}</span>
        </div>
      </div>

      {/* Ticker Bar */}
      <div className="border-t border-[#1c2227] bg-[#0b0e11] py-3.5 px-4 text-[10px] md:text-xs font-bold tracking-[0.15em] text-[#adb4bb]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-around gap-4 uppercase">
          <span className="flex items-center gap-1.5 text-[#ffe000]">
            <Flame className="h-3.5 w-3.5 fill-current" />
            AWSK ANIMEX
          </span>
          <span className="text-[#ffe000]">✦ POWERED BY AWSK_EDITZ</span>
          <span>✦ HAR KAHANI MEIN EK NAYI DUNIYA</span>
          <span className="text-[#ffe000]">✦ HINGLISH MANGA</span>
          <span>✦ FAN-MADE ANIMATION</span>
          <span className="text-red-400">✦ 4,230+ SUBSCRIBERS</span>
        </div>
      </div>
    </section>
  );
};
