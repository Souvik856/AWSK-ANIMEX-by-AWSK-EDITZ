import React from 'react';
import { Manga } from '../types';
import { Crown, ArrowUpRight, BookOpen, Sparkles } from 'lucide-react';

interface FeaturedMangaProps {
  mangaList: Manga[];
  onReadManga: (manga: Manga) => void;
  onOpenDetails: (manga: Manga) => void;
}

export const FeaturedManga: React.FC<FeaturedMangaProps> = ({
  mangaList,
  onReadManga,
  onOpenDetails
}) => {
  const featured = mangaList.filter((m) => m.featured).slice(0, 2);
  const primary = featured[0] || mangaList[0];
  const secondary = featured[1] || mangaList[1];

  if (!primary) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 md:px-8 pt-10">
      {/* Section Head */}
      <div className="flex items-end justify-between border-b border-[#20272e] pb-3 mb-6">
        <div>
          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
            <Crown className="h-3 w-3 fill-current" />
            READ SOMETHING LEGENDARY
          </div>
          <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
            Featured <span className="text-[#ffe000]">Manga</span>
          </h2>
        </div>
        <a
          href="#manga"
          className="text-xs font-bold text-[#ffe000] hover:underline flex items-center gap-1"
        >
          Explore library <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </div>

      {/* Featured Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Main Big Feature Card */}
        {primary && (
          <div className="relative lg:col-span-7 h-[340px] sm:h-[380px] overflow-hidden rounded-2xl border border-[#303941] bg-[#11161b] shadow-2xl group">
            <img
              src={primary.coverUrl}
              alt={primary.title}
              className="absolute inset-0 h-full w-full object-cover opacity-70 transition duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#07090bf5] via-[#07090bcf] to-[#07090b20]" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07090bf0] via-transparent to-transparent" />

            <div className="absolute inset-0 p-6 sm:p-8 flex flex-col justify-between max-w-lg">
              <div>
                <span className="inline-flex items-center gap-1 rounded bg-[#0b0d0bb0] border border-[#ffe0005c] px-2.5 py-1 text-[9px] font-black tracking-widest text-[#ffe000] uppercase">
                  <Sparkles className="h-2.5 w-2.5" />
                  ORIGINAL SERIES
                </span>
                <h3 className="font-heading mt-3 text-3xl sm:text-4xl font-black uppercase text-white leading-tight">
                  {primary.title}
                </h3>
                <p className="mt-2 text-xs sm:text-sm text-[#c1c6ca] line-clamp-3 leading-relaxed">
                  {primary.description}
                </p>

                {/* Genre Pills */}
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {primary.genres?.map((g) => (
                    <span
                      key={g}
                      className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-[9px] font-medium text-[#d1d5d9]"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onReadManga(primary)}
                    className="flex items-center gap-1.5 rounded-xl bg-[#ffe000] px-4 py-2.5 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95 shadow-md"
                  >
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>Read Now</span>
                  </button>
                  <button
                    onClick={() => onOpenDetails(primary)}
                    className="rounded-xl border border-[#444d56] bg-[#0c1014a6] px-4 py-2.5 text-xs font-bold text-white hover:border-[#ffe000] hover:text-[#ffe000] transition"
                  >
                    View Details
                  </button>
                </div>
                <span className="text-[10px] text-[#8e98a1] uppercase tracking-wider font-semibold">
                  {primary.status} · Ch. 0{primary.totalChapters || 1}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Secondary Featured Card */}
        {secondary && (
          <div className="relative lg:col-span-5 h-[340px] sm:h-[380px] overflow-hidden rounded-2xl border border-[#ff3b3133] bg-[#140e10] shadow-2xl group">
            <img
              src={secondary.coverUrl}
              alt={secondary.title}
              className="absolute inset-0 h-full w-full object-cover opacity-60 transition duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0d0708f5] via-[#0d0708cc] to-[#0d070830]" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0d0708f0] via-transparent to-transparent" />

            <div className="absolute inset-0 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <span className="inline-flex items-center gap-1 rounded bg-[#ff3b3120] border border-[#ff3b315c] px-2.5 py-1 text-[9px] font-black tracking-widest text-[#ff7069] uppercase">
                  NEW CHAPTER
                </span>
                <h3 className="font-heading mt-3 text-2xl sm:text-3xl font-black uppercase text-white leading-tight">
                  {secondary.title}
                </h3>
                <p className="mt-2 text-xs text-[#c1c6ca] line-clamp-3 leading-relaxed">
                  {secondary.description}
                </p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  {secondary.genres?.map((g) => (
                    <span
                      key={g}
                      className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-[9px] font-medium text-[#d1d5d9]"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <button
                  onClick={() => onReadManga(secondary)}
                  className="flex items-center gap-1.5 rounded-xl border border-[#ff3b3166] bg-[#ff3b3120] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#ff3b3140] transition"
                >
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>Read Chapter 0{secondary.totalChapters || 1}</span>
                </button>
                <button
                  onClick={() => onOpenDetails(secondary)}
                  className="text-xs font-bold text-[#ff7069] hover:underline"
                >
                  Details ↗
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
