import React, { useEffect, useState } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-yellow-500/50 bg-[#12161b] px-3.5 py-2 text-xs font-semibold text-[#ffe000] shadow-2xl backdrop-blur-md">
      <WifiOff className="h-4 w-4" />
      <span>Offline Mode — Reading from local cache</span>
    </div>
  );
};

export const PWAUpdateToast: React.FC = () => {
  const { hasUpdate, updateApp } = usePWAInstall();

  if (!hasUpdate) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-3 rounded-xl border border-[#ffe000] bg-[#0e1216] p-3 text-xs text-white shadow-2xl animate-bounce">
      <div>
        <strong className="block text-[#ffe000]">Update Ready!</strong>
        <span className="text-[10px] text-gray-300">New chapters &amp; features available.</span>
      </div>
      <button
        onClick={updateApp}
        className="flex items-center gap-1 rounded-lg bg-[#ffe000] px-3 py-1.5 text-xs font-black text-black hover:bg-yellow-300"
      >
        <RefreshCw className="h-3 w-3" />
        <span>Refresh</span>
      </button>
    </div>
  );
};
