import React from 'react';
import { Manga, Chapter } from '../types';
import { useData } from '../context/DataContext';
import { X, Bookmark, BookOpen, Clock, ArrowUpRight, Sparkles } from 'lucide-react';

interface MangaDetailModalProps {
  manga: Manga | null;
  onClose: () => void;
  onReadChapter: (manga: Manga, chapter?: Chapter) => void;
}

export const MangaDetailModal: React.FC<MangaDetailModalProps> = ({
  manga,
  onClose,
  onReadChapter
}) => {
  const { chaptersList, toggleBookmark, isBookmarked } = useData();

  if (!manga) return null;

  const chapters = chaptersList
    .filter((c) => c.mangaId === manga.id && c.status === 'published')
    .sort((a, b) => b.chapterNumber - a.chapterNumber);

  const bookmarked = isBookmarked(manga.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative flex flex-col max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0c1015] shadow-2xl z-10">
        
        {/* Header Bar */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] px-6 py-4 bg-[#0f141b]">
          <span className="font-heading text-lg font-black text-[#ffe000] uppercase">
            MANGA OVERVIEW
          </span>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#303840] text-gray-300 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Top Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-start">
            <div className="sm:col-span-4 overflow-hidden rounded-xl border border-[#263039] bg-[#121820]">
              <img
                src={manga.coverUrl}
                alt={manga.title}
                className="w-full h-auto object-cover"
              />
            </div>

            <div className="sm:col-span-8 flex flex-col justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="rounded bg-[#ffe00020] border border-[#ffe00055] px-2 py-0.5 text-[9px] font-black text-[#ffe000] uppercase">
                    {manga.type}
                  </span>
                  <span className="rounded bg-white/10 px-2 py-0.5 text-[9px] font-bold text-gray-300 uppercase">
                    {manga.status}
                  </span>
                </div>

                <h2 className="font-heading text-3xl sm:text-4xl font-black uppercase text-white leading-tight">
                  {manga.title}
                </h2>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {manga.genres?.map((g) => (
                    <span
                      key={g}
                      className="rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-[10px] text-[#c0c7cf]"
                    >
                      {g}
                    </span>
                  ))}
                </div>

                <p className="mt-4 text-xs sm:text-sm text-[#b0b8c0] leading-relaxed">
                  {manga.description}
                </p>
              </div>

              {/* Creator Metadata */}
              <div className="mt-6 pt-4 border-t border-[#1f2730] grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="block text-[10px] text-[#78848f] uppercase">Author / Story</span>
                  <strong className="text-white font-semibold">{manga.author || 'AWSK Universe'}</strong>
                </div>
                <div>
                  <span className="block text-[10px] text-[#78848f] uppercase">Channel Editor</span>
                  <strong className="text-[#ffe000] font-semibold">{manga.editor || 'Souvik Deb'}</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onReadChapter(manga, chapters[0])}
              className="flex items-center gap-2 rounded-xl bg-[#ffe000] px-5 py-3 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95 shadow-md shadow-yellow-500/10"
            >
              <BookOpen className="h-4 w-4" />
              <span>Read Latest Chapter (Ch. 0{chapters[0]?.chapterNumber || 1})</span>
            </button>

            <button
              onClick={() => toggleBookmark(manga)}
              className={`flex items-center gap-2 rounded-xl border px-4 py-3 text-xs font-bold transition ${
                bookmarked
                  ? 'border-[#ffe000] bg-[#ffe00020] text-[#ffe000]'
                  : 'border-[#303840] bg-[#10151a] text-white hover:border-[#ffe000]'
              }`}
            >
              <Bookmark className="h-4 w-4 fill-current" />
              <span>{bookmarked ? 'Saved in Bookmarks' : 'Bookmark Manga'}</span>
            </button>
          </div>

          {/* Chapters Catalog */}
          <div className="mt-8 pt-6 border-t border-[#1f262e]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-heading text-xl font-bold uppercase text-white flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-[#ffe000]" />
                Available Chapters ({chapters.length})
              </h3>
              <span className="text-[10px] text-[#78828b] uppercase">Hinglish Translation</span>
            </div>

            {chapters.length === 0 ? (
              <p className="text-xs text-[#78828b] py-4 text-center">
                New chapters for this manga will be published soon by editor Souvik Deb.
              </p>
            ) : (
              <div className="divide-y divide-[#1a2128] rounded-xl border border-[#222a30] bg-[#090c0f] overflow-hidden">
                {chapters.map((ch) => (
                  <div
                    key={ch.id}
                    onClick={() => onReadChapter(manga, ch)}
                    className="p-3.5 flex items-center justify-between hover:bg-white/[0.03] transition cursor-pointer group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded bg-[#ffe00020] px-1.5 py-0.5 text-[9px] font-black text-[#ffe000]">
                          CH. 0{ch.chapterNumber}
                        </span>
                        <strong className="text-xs font-bold text-white group-hover:text-[#ffe000] transition">
                          {ch.title}
                        </strong>
                      </div>
                      <span className="mt-1 flex items-center gap-1 text-[10px] text-[#78828b]">
                        <Clock className="h-2.5 w-2.5" />
                        Released {new Date(ch.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <button className="flex items-center gap-1 text-xs font-bold text-[#ffe000] group-hover:translate-x-1 transition-transform">
                      <span>Read</span>
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
