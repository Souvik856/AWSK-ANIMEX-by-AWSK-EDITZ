import React from 'react';
import { Manga, Chapter } from '../types';
import { ArrowUpRight, BookOpen, Clock, Youtube, Sparkles } from 'lucide-react';
import { useData } from '../context/DataContext';

interface LatestChaptersProps {
  mangaList: Manga[];
  chaptersList: Chapter[];
  searchQuery: string;
  onReadChapter: (manga: Manga, chapter?: Chapter) => void;
  onOpenDetails: (manga: Manga) => void;
}

export const LatestChapters: React.FC<LatestChaptersProps> = ({
  mangaList,
  chaptersList,
  searchQuery,
  onReadChapter,
  onOpenDetails
}) => {
  const { siteSettings } = useData();

  // Filter manga based on search
  const filteredManga = mangaList.filter((m) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.title.toLowerCase().includes(q) ||
      m.description.toLowerCase().includes(q) ||
      m.genres.some((g) => g.toLowerCase().includes(q))
    );
  });

  return (
    <section id="manga" className="mx-auto max-w-7xl px-4 md:px-8 pt-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main 8-column area: Latest Chapters Grid */}
        <div className="lg:col-span-8">
          <div className="flex items-end justify-between border-b border-[#20272e] pb-3 mb-6">
            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
                FRESH OFF THE PRESS
              </div>
              <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
                Latest <span className="text-[#ffe000]">Chapters</span>
              </h2>
            </div>
            <span className="text-xs text-[#737e87]">
              {filteredManga.length} titles available
            </span>
          </div>

          {filteredManga.length === 0 ? (
            <div className="rounded-2xl border border-[#242b32] bg-[#0c1014] p-8 text-center text-sm text-[#8c96a0]">
              No manga titles match "{searchQuery}". Try searching for Action, Fantasy, or Shadows.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {filteredManga.map((manga, idx) => {
                // Find latest chapter for this manga
                const latestCh = chaptersList.find((c) => c.mangaId === manga.id);
                const chNum = latestCh?.chapterNumber || manga.totalChapters || 1;

                return (
                  <article
                    key={manga.id}
                    className="group relative flex flex-col overflow-hidden rounded-xl border border-[#263039] bg-gradient-to-b from-[#11171c] to-[#090b0d] transition duration-300 hover:-translate-y-1.5 hover:border-[#ffe00066] shadow-lg"
                  >
                    {/* Thumbnail Art */}
                    <div className="relative h-[200px] w-full overflow-hidden bg-[#121820]">
                      <img
                        src={manga.coverUrl}
                        alt={manga.title}
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-105 opacity-85"
                      />
                      
                      {/* Chapter Badge */}
                      <span className="absolute bottom-2 left-2 rounded bg-[#07090ded] px-2 py-0.5 text-[9px] font-black tracking-wide text-white border border-white/10">
                        CH. 0{chNum}
                      </span>

                      {/* New Badge */}
                      {idx === 0 && (
                        <span className="absolute bottom-2 right-2 rounded bg-[#ffe000] px-2 py-0.5 text-[9px] font-black text-black">
                          NEW
                        </span>
                      )}
                    </div>

                    {/* Card Body */}
                    <div className="flex flex-1 flex-col justify-between p-3.5">
                      <div>
                        <h3
                          onClick={() => onOpenDetails(manga)}
                          className="font-bold text-xs sm:text-sm text-white line-clamp-1 group-hover:text-[#ffe000] transition-colors cursor-pointer"
                        >
                          {manga.title}
                        </h3>
                        <p className="mt-1 text-[10px] text-[#9ba4ad] line-clamp-1">
                          {manga.genres.slice(0, 2).join(' · ')}
                        </p>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-[#1d252c] flex items-center justify-between">
                        <button
                          onClick={() => onReadChapter(manga, latestCh)}
                          className="flex items-center gap-1 text-[11px] font-bold text-[#ffe000] hover:underline"
                        >
                          <span>Read</span>
                          <ArrowUpRight className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => onOpenDetails(manga)}
                          className="text-[10px] text-[#737e87] hover:text-white"
                        >
                          Info
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 4-column sidebar (matching screenshot Image 1) */}
        <aside className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Join Our Community Box */}
          <div className="relative overflow-hidden rounded-2xl border border-[#ffe00033] bg-gradient-to-br from-[#15130b] via-[#0d1014] to-[#080a0c] p-6 shadow-xl">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
                  COMMUNITY
                </span>
                <h3 className="font-heading mt-1 text-2xl font-black uppercase text-white">
                  Join Our Community
                </h3>
              </div>
              <span className="text-2xl text-[#ffe000]">♛</span>
            </div>

            <p className="mt-2 text-xs text-[#aeb5bb] leading-relaxed">
              Follow us on YouTube &amp; Instagram for the latest updates, chapter drops, and anime edits!
            </p>

            <div className="mt-5 flex items-center gap-3">
              <a
                href={siteSettings.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-xl bg-[#ffe000] px-4 py-2.5 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95 shadow-md shadow-yellow-500/10"
              >
                <Youtube className="h-4 w-4" />
                <span>Follow Now</span>
              </a>
              <span className="text-[11px] font-bold text-[#ff6a61]">
                4,230+ Fam
              </span>
            </div>
          </div>

          {/* Latest Updates Feed */}
          <div className="rounded-2xl border border-[#242b32] bg-[#0c1014] p-5 shadow-lg">
            <div className="flex items-center justify-between border-b border-[#1f262d] pb-3 mb-3">
              <h4 className="font-heading text-lg font-black uppercase text-white flex items-center gap-1.5">
                <Sparkles className="h-4 w-4 text-[#ffe000]" />
                Latest Updates
              </h4>
              <span className="text-[9px] font-bold text-[#ffe000] uppercase tracking-wider">
                LIVE
              </span>
            </div>

            <div className="divide-y divide-[#1a2128]">
              {useData().newsList.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    if (item.linkUrl?.startsWith('#')) {
                      const el = document.querySelector(item.linkUrl);
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="py-2.5 flex items-center justify-between group cursor-pointer hover:bg-white/[0.02] px-1 rounded transition"
                >
                  <div className="pr-2">
                    <span className="text-[9px] font-black text-[#ffe000] uppercase block">
                      {item.category}
                    </span>
                    <p className="text-xs font-bold text-white group-hover:text-[#ffe000] transition line-clamp-1">
                      {item.title}
                    </p>
                    <span className="flex items-center gap-1 text-[9px] text-[#78828b] mt-0.5">
                      <Clock className="h-2.5 w-2.5" />
                      {new Date(item.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <ArrowUpRight className="h-3.5 w-3.5 text-[#55606b] group-hover:text-white transition shrink-0" />
                </div>
              ))}
            </div>
          </div>

        </aside>
      </div>
    </section>
  );
};
