import React, { useState, useEffect } from 'react';
import { Manga, Chapter } from '../types';
import { useData } from '../context/DataContext';
import { X, Bookmark, ChevronLeft, ChevronRight, BookOpen, Scroll, Sliders, Check } from 'lucide-react';

interface MangaReaderModalProps {
  manga: Manga | null;
  initialChapter?: Chapter | null;
  onClose: () => void;
}

export const MangaReaderModal: React.FC<MangaReaderModalProps> = ({
  manga,
  initialChapter,
  onClose
}) => {
  const { chaptersList, toggleBookmark, isBookmarked, recordReadingHistory } = useData();

  // Find all chapters for this manga
  const mangaChapters = chaptersList
    .filter((c) => c.mangaId === manga?.id && c.status === 'published')
    .sort((a, b) => a.chapterNumber - b.chapterNumber);

  // Active chapter
  const [activeChapter, setActiveChapter] = useState<Chapter | null>(
    initialChapter || mangaChapters[0] || null
  );

  // Reading modes: 'text' (Hinglish Story) or 'comic' (Visual Webtoon) or 'split'
  const [readingMode, setReadingMode] = useState<'scroll' | 'page'>('scroll');
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg'>('base');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialChapter) {
      setActiveChapter(initialChapter);
    } else if (mangaChapters.length > 0) {
      setActiveChapter(mangaChapters[0]);
    }
  }, [initialChapter, manga]);

  useEffect(() => {
    if (manga && activeChapter) {
      recordReadingHistory(manga.id, activeChapter.id, activeChapter.chapterNumber);
    }
  }, [manga, activeChapter]);

  if (!manga) return null;

  const currentChIndex = mangaChapters.findIndex((c) => c.id === activeChapter?.id);
  const prevChapter = currentChIndex > 0 ? mangaChapters[currentChIndex - 1] : null;
  const nextChapter = currentChIndex >= 0 && currentChIndex < mangaChapters.length - 1 ? mangaChapters[currentChIndex + 1] : null;

  const bookmarked = isBookmarked(manga.id);

  const handleBookmark = async () => {
    await toggleBookmark(manga, activeChapter?.chapterNumber || 1);
    showToast(bookmarked ? 'Bookmark removed' : 'Bookmark saved to your account!');
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Split story into paragraphs
  const paragraphs = activeChapter?.hinglishText
    ? activeChapter.hinglishText.split('\n\n').filter((p) => p.trim())
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md">
      {/* Backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Reader Panel */}
      <div className="relative flex flex-col h-[94vh] w-full max-w-4xl overflow-hidden rounded-2xl border border-[#303840] bg-[#0b0e12] shadow-2xl z-10">
        
        {/* Top Header Bar */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#222a30] bg-[#0d1217] px-4 md:px-6 py-3.5">
          <div className="flex items-center gap-3 overflow-hidden">
            <span className="font-heading text-lg font-black text-[#ffe000] hidden sm:inline">
              AWSK READER
            </span>
            <div className="h-4 w-[1px] bg-[#303840] hidden sm:block" />
            <div className="truncate">
              <h2 className="text-xs sm:text-sm font-bold text-white truncate">
                {manga.title}
              </h2>
              <span className="text-[10px] text-[#ffe000] font-semibold">
                {activeChapter ? `Chapter 0${activeChapter.chapterNumber} — ${activeChapter.title}` : 'Chapter Preview'}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            {/* Reading mode toggle */}
            <div className="hidden sm:flex items-center rounded-lg border border-[#303840] bg-[#080b0e] p-0.5">
              <button
                onClick={() => setReadingMode('scroll')}
                className={`flex items-center gap-1 rounded px-2 py-1 text-[10px] font-bold transition ${
                  readingMode === 'scroll' ? 'bg-[#ffe000] text-black' : 'text-[#8c96a0] hover:text-white'
                }`}
                title="Continuous Webtoon Scroll"
              >
                <Scroll className="h-3 w-3" />
                <span>Scroll</span>
              </button>
              <button
                onClick={() => setReadingMode('page')}
                className={`flex items-center gap-1 rounded px-2 py-1 text-[10px] font-bold transition ${
                  readingMode === 'page' ? 'bg-[#ffe000] text-black' : 'text-[#8c96a0] hover:text-white'
                }`}
                title="Single Focus View"
              >
                <BookOpen className="h-3 w-3" />
                <span>Focus</span>
              </button>
            </div>

            {/* Font size toggle */}
            <div className="hidden md:flex items-center rounded-lg border border-[#303840] bg-[#080b0e] p-0.5 text-[10px] font-bold text-[#8c96a0]">
              <button
                onClick={() => setFontSize('sm')}
                className={`px-1.5 py-1 rounded ${fontSize === 'sm' ? 'text-[#ffe000] bg-white/5' : ''}`}
              >
                A-
              </button>
              <button
                onClick={() => setFontSize('base')}
                className={`px-1.5 py-1 rounded ${fontSize === 'base' ? 'text-[#ffe000] bg-white/5' : ''}`}
              >
                A
              </button>
              <button
                onClick={() => setFontSize('lg')}
                className={`px-1.5 py-1 rounded ${fontSize === 'lg' ? 'text-[#ffe000] bg-white/5' : ''}`}
              >
                A+
              </button>
            </div>

            {/* Bookmark button */}
            <button
              onClick={handleBookmark}
              className={`flex items-center gap-1 rounded-lg border px-3 py-1.5 text-xs font-bold transition ${
                bookmarked
                  ? 'border-[#ffe000] bg-[#ffe00020] text-[#ffe000]'
                  : 'border-[#303840] bg-[#10151a] text-white hover:border-[#ffe000]'
              }`}
            >
              <Bookmark className="h-3.5 w-3.5 fill-current" />
              <span className="hidden sm:inline">{bookmarked ? 'Saved' : 'Bookmark'}</span>
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#303840] text-gray-300 hover:border-red-500 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Reader Content */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-8 md:px-12 py-8 bg-[#07090b]">
          
          {/* Cover Header in Reader */}
          <div className="mx-auto max-w-2xl mb-8 overflow-hidden rounded-xl border border-[#242c34] bg-[#0f141a]">
            <img
              src={manga.coverUrl}
              alt={manga.title}
              className="h-48 sm:h-64 w-full object-cover opacity-85"
            />
            <div className="p-4 bg-gradient-to-t from-[#0d1217] via-[#0d1217] to-transparent flex flex-wrap items-center justify-between gap-2 border-t border-[#1d232a]">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#ffe000]">
                HINGLISH MANGA · OFFICIAL AWSK RELEASE
              </span>
              <span className="text-[10px] text-[#8e98a2]">
                Edited by Souvik Deb
              </span>
            </div>
          </div>

          {/* Uploaded Comic Images (if any comic pages exist) */}
          {activeChapter?.pages && activeChapter.pages.length > 0 && (
            <div className="mx-auto max-w-2xl mb-10 flex flex-col gap-4">
              <div className="text-center text-[10px] font-black uppercase tracking-widest text-[#ffe000] border-b border-[#242c34] pb-2">
                COMIC PAGES
              </div>
              {activeChapter.pages.map((pageUrl, pIdx) => (
                <div
                  key={pIdx}
                  className="overflow-hidden rounded-xl border border-[#222a32] bg-[#090b0e] shadow-xl"
                >
                  <img
                    src={pageUrl}
                    alt={`Page ${pIdx + 1}`}
                    className="w-full h-auto object-contain"
                  />
                  <div className="p-2 text-center text-[9px] text-[#636c75]">
                    Page {pIdx + 1} of {activeChapter.pages?.length}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Hinglish Chapter Story Text */}
          <div className={`mx-auto max-w-2xl leading-relaxed text-[#d5d9dd] ${
            fontSize === 'sm' ? 'text-xs md:text-sm' : fontSize === 'lg' ? 'text-base md:text-lg' : 'text-sm md:text-base'
          }`}>
            <div className="mb-6 pb-4 border-b border-[#1f2730] text-center">
              <span className="text-[10px] font-black text-[#ffe000] tracking-widest uppercase">
                CHAPTER 0{activeChapter?.chapterNumber || 1}
              </span>
              <h3 className="font-heading mt-1 text-2xl md:text-3xl font-black text-white uppercase">
                {activeChapter?.title || 'Story Script'}
              </h3>
            </div>

            {paragraphs.length > 0 ? (
              <div className="space-y-5">
                {paragraphs.map((p, idx) => (
                  <p key={idx} className="leading-loose tracking-wide">
                    {p}
                  </p>
                ))}
              </div>
            ) : (
              <p className="text-center text-sm text-[#78848f] py-8">
                Chapter dialogue being finalized by editorial team. Check back shortly!
              </p>
            )}

            {/* Chapter End Notice */}
            <div className="my-10 text-center border-t border-b border-[#20272e] py-6">
              <span className="font-heading text-lg font-black tracking-widest text-[#ffe000] uppercase">
                ✦ CHAPTER 0{activeChapter?.chapterNumber || 1} COMPLETE · TO BE CONTINUED ✦
              </span>
              <p className="mt-1 text-[11px] text-[#7d8791]">
                Leave your theories and feedback on our YouTube community tab!
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Navigation Toolbar */}
        <div className="flex shrink-0 items-center justify-between border-t border-[#222a30] bg-[#0d1217] px-4 md:px-6 py-3">
          {/* Prev Chapter */}
          <button
            disabled={!prevChapter}
            onClick={() => prevChapter && setActiveChapter(prevChapter)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition ${
              prevChapter
                ? 'border-[#303840] bg-[#12171c] text-white hover:border-[#ffe000] hover:text-[#ffe000]'
                : 'border-transparent text-gray-600 cursor-not-allowed opacity-40'
            }`}
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Prev Chapter</span>
          </button>

          {/* Chapter Selector Dropdown */}
          <div className="flex items-center gap-2">
            <select
              value={activeChapter?.id || ''}
              onChange={(e) => {
                const found = mangaChapters.find((c) => c.id === e.target.value);
                if (found) setActiveChapter(found);
              }}
              className="rounded-xl border border-[#303840] bg-[#12171c] px-3 py-2 text-xs font-bold text-white focus:border-[#ffe000] focus:outline-none"
            >
              {mangaChapters.map((c) => (
                <option key={c.id} value={c.id}>
                  Ch. 0{c.chapterNumber}: {c.title}
                </option>
              ))}
            </select>
          </div>

          {/* Next Chapter */}
          <button
            disabled={!nextChapter}
            onClick={() => nextChapter && setActiveChapter(nextChapter)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition ${
              nextChapter
                ? 'border-[#ffe000] bg-[#ffe000] text-black hover:bg-yellow-300'
                : 'border-transparent text-gray-600 cursor-not-allowed opacity-40'
            }`}
          >
            <span className="hidden sm:inline">Next Chapter</span>
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* Toast Notification */}
        {toastMessage && (
          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 rounded-xl bg-[#ffe000] px-4 py-2 text-xs font-black text-black shadow-2xl flex items-center gap-1.5 animate-bounce">
            <Check className="h-3.5 w-3.5" />
            <span>{toastMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};
