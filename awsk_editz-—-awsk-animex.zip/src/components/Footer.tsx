import React from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Crown } from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPrivacy, onOpenAdmin }) => {
  const { isInstallable, install } = usePWAInstall();

  return (
    <footer className="border-t border-[#1c2228] bg-[#080a0c] px-4 md:px-8 py-8 text-xs text-[#8c959c]">
      <div className="mx-auto max-w-7xl flex flex-wrap items-center justify-between gap-6">
        
        {/* Brand */}
        <div>
          <a href="#home" className="flex items-center gap-1.5">
            <span className="font-heading text-xl font-black italic tracking-tighter text-[#ffe000] -skew-x-6">
              AWSK <span className="text-white">ANIMEX</span>
            </span>
            <span className="text-xs text-[#ffe000]">♛</span>
          </a>
          <p className="mt-0.5 text-[10px] font-bold text-[#ffe000] uppercase tracking-wider">
            Powered by AWSK_EDITZ
          </p>
          <p className="mt-1 text-[11px] text-[#78828b]">
            Beyond Anime. Beyond Imagination. · <em>Har Kahani Mein Ek Nayi Duniya.</em>
          </p>
        </div>

        {/* Footer Links */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-[#adb5be]">
          <a href="#home" className="hover:text-[#ffe000] transition">Home</a>
          <a href="#manga" className="hover:text-[#ffe000] transition">Manga</a>
          <a href="#animations" className="hover:text-[#ffe000] transition">Animations</a>
          <a href="#edits" className="hover:text-[#ffe000] transition">Edits</a>
          <a href="#contact" className="hover:text-[#ffe000] transition">Contact</a>
          <button onClick={onOpenPrivacy} className="hover:text-[#ffe000] transition">
            Privacy &amp; DMCA
          </button>
          <button onClick={onOpenAdmin} className="hover:text-[#ffe000] transition text-[#ffe000]">
            Admin Portal
          </button>
        </div>

        {/* PWA Button */}
        {isInstallable && (
          <button
            onClick={install}
            className="flex items-center gap-1.5 rounded-full bg-[#ffe000] px-3.5 py-1.5 text-xs font-black text-black hover:bg-yellow-300 transition"
          >
            <Download className="h-3 w-3" />
            <span>Install App</span>
          </button>
        )}
      </div>

      <div className="mx-auto max-w-7xl mt-6 pt-4 border-t border-[#151a1e] flex flex-wrap items-center justify-between gap-3 text-[10px] text-[#636c75]">
        <span>
          © {new Date().getFullYear()} AWSK_EDITZ · Built for the anime fandom.
        </span>
        <span className="flex items-center gap-1">
          <Crown className="h-3 w-3 text-[#ffe000]" />
          Channel Editor: Souvik Deb
        </span>
      </div>
    </footer>
  );
};
