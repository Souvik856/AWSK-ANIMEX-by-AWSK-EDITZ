import React from 'react';
import { AnimationProject } from '../types';
import { Play, Youtube, Sparkles } from 'lucide-react';
import { useData } from '../context/DataContext';

interface AnimationsShowcaseProps {
  animationsList: AnimationProject[];
  onPlayAnimation: (anim: AnimationProject) => void;
}

export const AnimationsShowcase: React.FC<AnimationsShowcaseProps> = ({
  animationsList,
  onPlayAnimation
}) => {
  const { siteSettings } = useData();
  const spotlight = animationsList.find((a) => a.featured) || animationsList[0];

  if (!spotlight) return null;

  return (
    <section id="animations" className="mx-auto max-w-7xl px-4 md:px-8 pt-16">
      <div className="flex items-end justify-between border-b border-[#20272e] pb-3 mb-6">
        <div>
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
            FROM PANELS TO MOTION
          </div>
          <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
            Fan-made <span className="text-[#ffe000]">Animations</span>
          </h2>
        </div>
        <span className="text-xs text-[#737e87]">Trailers · Shorts · Projects</span>
      </div>

      <article className="relative h-[320px] sm:h-[380px] w-full overflow-hidden rounded-2xl border border-[#263039] bg-[#101316] shadow-2xl group">
        <img
          src={spotlight.thumbnailUrl || '/assets/animation-preview.jpg'}
          alt={spotlight.title}
          className="absolute inset-0 h-full w-full object-cover opacity-70 transition duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050607f0] via-[#050607c0] to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050607f0] via-transparent to-transparent" />

        {/* Center Play Button */}
        <button
          onClick={() => onPlayAnimation(spotlight)}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex h-16 w-16 items-center justify-center rounded-full border-2 border-white/80 bg-[#090b0bcc] text-[#ffe000] shadow-[0_0_35px_rgba(0,0,0,0.8)] transition duration-300 hover:scale-110 hover:border-[#ffe000]"
          aria-label="Play animation trailer"
        >
          <Play className="h-7 w-7 fill-current translate-x-0.5" />
        </button>

        {/* Bottom Left Info */}
        <div className="absolute bottom-6 left-6 md:left-8 max-w-lg">
          <span className="inline-flex items-center gap-1 rounded bg-[#0b0d0bb0] border border-[#ffe0005c] px-2.5 py-0.5 text-[8px] font-black tracking-widest text-[#ffe000] uppercase">
            <Sparkles className="h-2.5 w-2.5" />
            {spotlight.subtitle || 'PROJECT SPOTLIGHT'}
          </span>
          <h3 className="font-heading mt-2 text-3xl sm:text-4xl font-black uppercase text-white leading-tight">
            {spotlight.title}
          </h3>
          <p className="mt-1 text-xs text-[#c2c6ca] line-clamp-2 max-w-md leading-relaxed">
            {spotlight.description}
          </p>

          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => onPlayAnimation(spotlight)}
              className="flex items-center gap-2 rounded-xl bg-[#ffe000] px-4 py-2.5 text-xs font-black text-black hover:bg-yellow-300 transition active:scale-95"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Watch Trailer</span>
            </button>
            <a
              href={spotlight.youtubeUrl || siteSettings.youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-xl border border-[#48515a] bg-[#090c0d80] px-3.5 py-2.5 text-xs font-bold text-white hover:border-[#ffe000] hover:text-[#ffe000] transition"
            >
              <Youtube className="h-4 w-4 text-red-500" />
              <span>YouTube ↗</span>
            </a>
          </div>
        </div>

        {/* Duration badge */}
        <span className="absolute bottom-4 right-4 rounded bg-[#050607bd] px-2.5 py-1 text-[9px] font-bold text-gray-300 uppercase tracking-widest border border-white/5">
          {spotlight.duration || 'PREVIEW'}
        </span>
      </article>
    </section>
  );
};
