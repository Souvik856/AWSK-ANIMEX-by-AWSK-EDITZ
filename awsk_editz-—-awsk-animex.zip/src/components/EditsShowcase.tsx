import React from 'react';
import { AnimeEdit } from '../types';
import { Play, Youtube, ArrowUpRight } from 'lucide-react';
import { useData } from '../context/DataContext';

interface EditsShowcaseProps {
  editsList: AnimeEdit[];
  onPlayEdit: (edit: AnimeEdit) => void;
}

export const EditsShowcase: React.FC<EditsShowcaseProps> = ({ editsList, onPlayEdit }) => {
  const { siteSettings } = useData();

  return (
    <section id="edits" className="mx-auto max-w-7xl px-4 md:px-8 pt-16">
      <div className="flex items-end justify-between border-b border-[#20272e] pb-3 mb-6">
        <div>
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ffe000]">
            QUICK CUTS. BIG ENERGY.
          </div>
          <h2 className="font-heading mt-1 text-3xl md:text-4xl font-extrabold text-white uppercase tracking-tight">
            Latest <span className="text-[#ffe000]">Edits</span>
          </h2>
        </div>
        <a
          href={siteSettings.youtubeUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs font-bold text-[#ffe000] hover:underline flex items-center gap-1"
        >
          <span>Visit YouTube</span>
          <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5">
        {editsList.map((edit) => (
          <article
            key={edit.id}
            onClick={() => onPlayEdit(edit)}
            className="group relative flex flex-col overflow-hidden rounded-xl border border-[#263039] bg-[#0e1216] transition duration-300 hover:-translate-y-1.5 hover:border-[#ffe00066] cursor-pointer shadow-lg"
          >
            <div className="relative h-[155px] w-full overflow-hidden bg-[#151b22]">
              <img
                src={edit.thumbnailUrl || '/assets/manga-crimson.jpg'}
                alt={edit.title}
                className="h-full w-full object-cover transition duration-500 group-hover:scale-105 opacity-80"
              />
              
              {/* Play Badge */}
              <div className="absolute top-2.5 left-2.5 flex h-7 w-7 items-center justify-center rounded-full bg-[#08090dbd] text-[#ffe000] shadow-md group-hover:bg-[#ffe000] group-hover:text-black transition">
                <Play className="h-3 w-3 fill-current translate-x-0.2" />
              </div>

              {/* Duration */}
              <span className="absolute bottom-2 right-2 rounded bg-black/80 px-1.5 py-0.5 text-[8px] font-bold text-gray-300">
                {edit.duration}
              </span>
            </div>

            <div className="p-3">
              <strong className="block text-xs font-bold text-white line-clamp-1 group-hover:text-[#ffe000] transition-colors">
                {edit.title}
              </strong>
              <small className="mt-0.5 block text-[10px] text-[#939ca4] line-clamp-1">
                {edit.category}
              </small>
            </div>
          </article>
        ))}
      </div>

      <p className="mt-4 text-[10px] text-[#68737c]">
        Official anime action cuts and fan edits published to our YouTube channel and Instagram feed.
      </p>
    </section>
  );
};
