import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Bookmark, Shield, Search, Menu, X, LogIn, LogOut, Download } from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenAdmin: () => void;
  onOpenBookmarks: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  setSearchQuery,
  onOpenAdmin,
  onOpenBookmarks
}) => {
  const { user, isAdmin, loginWithGoogle, logout } = useAuth();
  const { bookmarks, siteSettings } = useData();
  const { isInstallable, install, isIOS } = usePWAInstall();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showIOSHint, setShowIOSHint] = useState(false);

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else if (isIOS) {
      setShowIOSHint(true);
    } else {
      alert("To install AWSK_EDITZ, tap your browser's menu (⋮ or Share) and choose 'Install App' or 'Add to Home Screen'.");
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 h-[76px] w-full border-b border-[#24282c] bg-[#080a0df2] px-4 md:px-8 backdrop-blur-md">
        <div className="mx-auto flex h-full max-w-7xl items-center justify-between gap-4">
          
          {/* Brand Logo */}
          <a href="#home" className="group relative flex shrink-0 flex-col focus:outline-none">
            <div className="flex items-center gap-1.5">
              <span className="font-heading text-2xl md:text-3xl font-black italic tracking-tighter text-[#ffe000] -skew-x-6 transition group-hover:scale-105">
                AWSK <span className="text-white">ANIMEX</span>
              </span>
              <span className="text-xs text-[#ffe000] select-none">♛</span>
            </div>
            <span className="text-[9px] font-bold tracking-widest text-[#9ca3af] -mt-1 uppercase">
              Powered by <strong className="text-[#ffe000]">AWSK_EDITZ</strong>
            </span>
          </a>

          {/* Desktop Nav links */}
          <nav className="hidden lg:flex items-center gap-5 text-xs text-[#c0c5ca] font-medium tracking-wide">
            <a href="#home" className="hover:text-[#ffe000] transition-colors">Home</a>
            <a href="#manga" className="hover:text-[#ffe000] transition-colors">Manga</a>
            <a href="#universe" className="hover:text-[#ffe000] transition-colors">Anime Universe</a>
            <a href="#animations" className="hover:text-[#ffe000] transition-colors">Animations</a>
            <a href="#edits" className="hover:text-[#ffe000] transition-colors">Edits</a>
            <a href="#community" className="hover:text-[#ffe000] transition-colors">Community</a>
            <a href="#contact" className="hover:text-[#ffe000] transition-colors">Contact</a>
          </nav>

          {/* Actions & Search */}
          <div className="flex items-center gap-2.5">
            {/* Search Input */}
            <div className="relative hidden sm:flex items-center">
              <Search className="absolute left-3 h-3.5 w-3.5 text-[#89929a]" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search manga, stories..."
                className="h-[36px] w-[170px] md:w-[210px] rounded-full border border-[#303840] bg-[#0c1015] pl-9 pr-3 text-xs text-white placeholder-[#89929a] focus:border-[#ffe000] focus:outline-none transition"
              />
            </div>

            {/* Bookmarks Button */}
            <button
              onClick={onOpenBookmarks}
              title="My Bookmarks"
              className="relative flex h-[36px] items-center gap-1.5 rounded-full border border-[#303840] bg-[#0d1217] px-3 text-xs text-[#c0c5ca] hover:border-[#ffe000] hover:text-[#ffe000] transition"
            >
              <Bookmark className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Bookmarks</span>
              {bookmarks.length > 0 && (
                <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-[#ff3b31] px-1 text-[9px] font-bold text-white">
                  {bookmarks.length}
                </span>
              )}
            </button>

            {/* PWA Install Button */}
            <button
              onClick={handleInstallClick}
              className="flex h-[36px] items-center gap-1.5 rounded-full bg-[#ffe000] px-3.5 text-xs font-black text-black shadow-md shadow-[#ffe00020] hover:bg-[#fff266] transition active:scale-95"
            >
              <Download className="h-3.5 w-3.5 stroke-[2.5]" />
              <span>Install App</span>
            </button>

            {/* Admin or Login Button */}
            {isAdmin ? (
              <button
                onClick={onOpenAdmin}
                className="flex h-[36px] items-center gap-1.5 rounded-full border border-[#ffe000] bg-[#ffe00015] px-3 text-xs font-bold text-[#ffe000] hover:bg-[#ffe00025] transition"
              >
                <Shield className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Admin Setup</span>
              </button>
            ) : (
              <button
                onClick={onOpenAdmin}
                title="Admin Setup Login"
                className="flex h-[36px] items-center gap-1.5 rounded-full border border-[#303840] bg-[#0d1217] px-3 text-xs font-bold text-[#c0c5ca] hover:border-[#ffe000] hover:text-[#ffe000] transition"
              >
                <Shield className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Admin Login</span>
              </button>
            )}

            {/* Mobile menu hamburger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="flex lg:hidden h-[36px] w-[36px] items-center justify-center rounded-lg border border-[#303840] text-white hover:border-[#ffe000]"
              aria-label="Toggle navigation"
            >
              {menuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Mobile dropdown menu */}
        {menuOpen && (
          <div className="lg:hidden absolute top-[76px] left-0 w-full border-b border-[#24282c] bg-[#080a0dfc] px-6 py-5 shadow-2xl backdrop-blur-xl">
            <div className="mb-4">
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search manga, stories..."
                className="h-[38px] w-full rounded-full border border-[#303840] bg-[#0c1015] px-4 text-xs text-white placeholder-[#89929a] focus:border-[#ffe000] focus:outline-none"
              />
            </div>
            <div className="flex flex-col gap-3 text-sm font-semibold text-[#c0c5ca]">
              <a href="#home" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Home</a>
              <a href="#manga" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Manga Library</a>
              <a href="#universe" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Anime Universe</a>
              <a href="#animations" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Fan-made Animations</a>
              <a href="#edits" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Anime Edits</a>
              <a href="#community" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Community</a>
              <a href="#contact" onClick={() => setMenuOpen(false)} className="hover:text-[#ffe000]">Contact</a>
            </div>
            <div className="mt-4 pt-4 border-t border-[#222830] flex items-center justify-between">
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onOpenAdmin();
                }}
                className="flex items-center gap-2 text-xs font-bold text-[#ffe000]"
              >
                <Shield className="h-4 w-4" />
                {user ? (isAdmin ? 'Admin Dashboard' : user.email) : 'Admin Sign In'}
              </button>
              {user && (
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    logout();
                  }}
                  className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Logout
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* iOS Safari Installation Guide Modal */}
      {showIOSHint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-[#303840] bg-[#0d1217] p-6 text-white shadow-2xl">
            <h3 className="font-heading text-2xl font-bold text-[#ffe000]">Install AWSK_EDITZ on iPhone</h3>
            <p className="mt-2 text-xs text-gray-300 leading-relaxed">
              1. Tap the <strong className="text-white">Share</strong> icon at the bottom of Safari.<br />
              2. Scroll down and tap <strong className="text-white">Add to Home Screen</strong>.<br />
              3. Tap <strong className="text-white">Add</strong> in the top-right corner.
            </p>
            <button
              onClick={() => setShowIOSHint(false)}
              className="mt-5 w-full rounded-xl bg-[#ffe000] py-2.5 text-xs font-black text-black hover:bg-yellow-400"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
